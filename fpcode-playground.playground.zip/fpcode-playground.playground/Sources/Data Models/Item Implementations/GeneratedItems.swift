//
//  GeneratedItems.swift
//  fpcode
//
//  Created by Tom Shen on 2021/4/3.
//

import Foundation
import SwiftUI
import Combine

// MARK: - Fixed Generated item ID
// These items should have a fixed ID everytime when generated
let StartItemID = UUID()
let EndItemID = UUID()
let VariableItemID = UUID()

// MARK: - Generated Items
// Generated items cannot be added by the user
struct StartEndItem: FlowchartItem {
    var type: FlowchartItemType { .startEnd }
    var shape: FlowchartShape { .capsule }
    var name: String { isStart ? "Begin" : "End" }
    
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        // Start end item does not have content
        return nil
    }
    
    var id = UUID()
    var isStart: Bool
    
    var storage = SettingValuesStorage()
    
    init(isStart: Bool) {
        self.isStart = isStart
        self.id = isStart ? StartItemID : EndItemID
    }
    
    // Stub, this block cannot be created
    static func createDefaultItem() -> StartEndItem {
        return StartEndItem(isStart: true)
    }
}

struct VariableItem: FlowchartItem {
    var type: FlowchartItemType { .variable }
    var shape: FlowchartShape { .rectangle }
    var name: String { "Variables" }
    
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        if flowchart.variables.isEmpty {
            return "No variables"
        } else if flowchart.variables.count >= 1 && flowchart.variables.count <= 3 {
            return variableDisplayText(for: flowchart.variables)
        } else {
            // Generate text for 3+ items
            return flowchart.variables[0].makePreview() + "\n" + flowchart.variables[1].makePreview() + "\n+\(flowchart.variables.count - 2) more"
        }
    }
    
    private func variableDisplayText(for variables: [FlowchartVariable]) -> String {
        return variables
            .map { variable in
                return variable.makePreview() + "\n"
            }
            .reduce("", +)
            .trimmingCharacters(in: .newlines) // Remove the last newline
    }
    
    var id = VariableItemID
    
    var storage = SettingValuesStorage()
    
    // Stub, this block cannot be created
    static func createDefaultItem() -> VariableItem {
        VariableItem()
    }
}

struct PlaceholderItem: FlowchartItem {
    var type: FlowchartItemType { .placeholder }
    var shape: FlowchartShape { .dottedRectangle }
    var name: String { "" }
    
    var children: [FlowchartItemContainer] = []
    
    var id = UUID()
    
    var storage = SettingValuesStorage()
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        return nil
    }
    
    static func createDefaultItem() -> PlaceholderItem {
        PlaceholderItem()
    }
    
    var inspectorPreview: String {
        return "Placeholder"
    }
    
    // TODO: Disable placeholder?
    // Decide if we should disable placeholder from execution
}
