//
//  OperationItems.swift
//  fpcode
//
//  Created by Tom Shen on 2021/4/3.
//

import Foundation
import SwiftUI
import Combine

// Set Variable, Operation, Input, Output

// MARK: - Operational Items
struct SetVariableItem: FlowchartItem {
    var type: FlowchartItemType { .setVariable }
    var shape: FlowchartShape { .rectangle }
    var name: String { "Set Variable" }
    
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        var displayText = ""
        let variableName = setValueDisplayText(key: variable, flowchart: flowchart)
        displayText += variableName.text
        if variableName.isSuccessful {
            // Successfully fetched the name of variable, display the value
            displayText += " = "
            displayText += valueDisplayText(key: value, flowchart: flowchart)
        }
        return displayText
    }
    
    static func createDefaultItem() -> SetVariableItem {
        SetVariableItem()
    }
    
    var id = UUID()
    var storage = SettingValuesStorage()
    
    var variable: SetValuePicker.ValueKey { "variable" }
    var value: ValuePicker.ValueKey { "value" }
    
    var settings: FlowchartItemSettings {
        SetValuePicker(title: "Variable", variable: variable)
        
        // Only display value picker if variable is already selected
        if storage[variable.first] != nil {
            ValuePicker(title: "Value", baseVariable: variable.first, setValueBase: variable, valueKey: value)
        }
    }
    
    func execute(with runtime: FlowchartRuntime, completion: FlowchartRuntime.ExecuteCompletion, onInput: FlowchartRuntime.InputHandler) {
        do {
            // Require the variable and get assign value as usual
            let baseVariable = try VariablePicker.require(variable: variable.first, storage: storage, runtime: runtime)
            let assignValue = try ValuePicker.getValue(from: runtime, baseVariable: baseVariable, storage: storage, key: value)
            if SetValuePicker.isAssigningArray(key: variable, storage: storage) {
                // Assigning to array
                try SetValuePicker.assignToArray(runtime: runtime, key: variable, variable: baseVariable, settings: storage, assignValue: assignValue)
            } else {
                // Assigning single value
                baseVariable.value = assignValue
            }
            
            completion(.success(()), nil)
        } catch {
            completion(.failure(error), self)
            return
        }
    }
    
    func validateForExecution() throws {
        try validateVariable(key: variable.first)
        try validateValue(key: value)
    }
}

struct OperationItem: FlowchartItem {
    // For now we only allow integer types for operations
    var type: FlowchartItemType { .operation }
    var shape: FlowchartShape { .rectangle }
    var name: String { "Operation" }
    
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        var displayText = ""
        let variableName = variableDisplayText(key: variable, flowchart: flowchart)
        displayText += variableName.text
        if variableName.isSuccessful {
            let operationType = OperationTypes(rawValue: storage[operation] ?? 0)!
            // Successfully fetched the name of variable, display the value
            displayText += " \(operationType.displayValue) "
            displayText += valueDisplayText(key: operationValue, flowchart: flowchart)
        }
        return displayText
    }
    
    static func createDefaultItem() -> OperationItem {
        return OperationItem()
    }
    
    var id = UUID()
    var storage = SettingValuesStorage()
    
    var variable: UUIDKey { "variable" }
    var operation: IntKey { "operation" }
    var operationValue: ValuePicker.ValueKey { "value" }
    
    var settings: FlowchartItemSettings {
        VariablePicker(title: "Variable", variable: variable, allowedTypes: [.integer])
        
        if storage[variable] != nil {
            EnumPicker(title: "Operation", selecting: OperationTypes.self, defaultValue: .add, value: operation)
            
            ValuePicker(title: "Value", baseVariable: variable, valueKey: operationValue)
        }
    }
    
    func validateForExecution() throws {
        try validateVariable(key: variable)
        try validateValue(key: operationValue)
    }
    
    enum ExecutionError: LocalizedError {
        case unsupportedType
        case assignValueInvalid
        
        var errorDescription: String? {
            switch self {
            case .unsupportedType: return "Operation type is not integer"
            case .assignValueInvalid: return "Operation value must be integer"
            }
        }
    }
    
    func execute(with runtime: FlowchartRuntime, completion: FlowchartRuntime.ExecuteCompletion, onInput: FlowchartRuntime.InputHandler) {
        do {
            let variable = try VariablePicker.require(variable: self.variable, storage: storage, runtime: runtime)
            guard variable.type == .integer, var originalValue = variable.value as? Int else {
                throw ExecutionError.unsupportedType
            }
            
            let value = try ValuePicker.getValue(from: runtime, baseVariable: variable, storage: storage, key: operationValue)
            guard let intValue = value as? Int else {
                throw ExecutionError.assignValueInvalid
            }
            let operationType = try EnumPicker<OperationTypes>.get(value: operation, storage: storage, defaultValue: .add)
            operationType.execute(left: &originalValue, right: intValue)
            
            variable.value = originalValue
            
            completion(.success(()), nil)
        } catch {
            completion(.failure(error), self)
        }
    }
}

// MARK: - Input/Output

struct InputItem: FlowchartItem {
    var type: FlowchartItemType { .input }
    var shape: FlowchartShape { .parallelogram }
    var name: String { "Input" }
    
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        return variableDisplayText(key: variable, flowchart: flowchart).text
    }
    
    static func createDefaultItem() -> InputItem {
        InputItem()
    }
    
    var id = UUID()
    
    var storage = SettingValuesStorage()
    
    var variable: UUIDKey { "variable" }
    
    var settings: FlowchartItemSettings {
        VariablePicker(title: "Input", variable: variable)
    }
    
    func validateForExecution() throws {
        try validateVariable(key: variable)
    }
    
    func execute(with runtime: FlowchartRuntime, completion: @escaping FlowchartRuntime.ExecuteCompletion, onInput: @escaping FlowchartRuntime.InputHandler) {
        do {
            let inputVar = try VariablePicker.require(variable: variable, storage: storage, runtime: runtime)
            onInput(inputVar.info) { input in
                // Input finished, assign value
                do {
                    switch inputVar.type {
                    case .integer: inputVar.value = Int(input) ?? 0
                    case .string: inputVar.value = input
                    case .intArray: inputVar.value = try [Int].decode(from: input)
                    case .stringArray: inputVar.value = try [String].decode(from: input)
                    }
                } catch {
                    completion(.failure(error), self)
                }
                
                completion(.success(()), nil)
            }
        } catch {
            completion(.failure(error), self)
        }
    }
}

struct OutputItem: FlowchartItem {
    var type: FlowchartItemType { .output }
    var shape: FlowchartShape { .parallelogram }
    var name: String { "Output" }
    
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        return variableDisplayText(key: variable, flowchart: flowchart).text
    }
    
    static func createDefaultItem() -> OutputItem {
        OutputItem()
    }
    
    var id = UUID()
    var storage = SettingValuesStorage()
    
    var variable: UUIDKey { "variable" }
    var settings: FlowchartItemSettings {
        VariablePicker(title: "Output", variable: variable)
    }
    
    func validateForExecution() throws {
        try validateVariable(key: variable)
    }
    
    func execute(with runtime: FlowchartRuntime, completion: FlowchartRuntime.ExecuteCompletion, onInput: FlowchartRuntime.InputHandler) {
        do {
            let outputVar = try VariablePicker.require(variable: variable, storage: storage, runtime: runtime)
            runtime.output("\(outputVar.value)")
            
            completion(.success(()), nil)
        } catch {
            completion(.failure(error), self)
        }
    }
}
