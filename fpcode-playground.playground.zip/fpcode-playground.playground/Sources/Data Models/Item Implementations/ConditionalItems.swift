//
//  ConditionalItems.swift
//  fpcode
//
//  Created by Tom Shen on 2021/4/3.
//

import Foundation
import SwiftUI
import Combine

// If/If-Else

struct IfElseItem: FlowchartItem {
    var type: FlowchartItemType { .ifElse }
    var shape: FlowchartShape { .diamond }
    var name: String { "If/Else" }
    
    var usesChildren: Bool { true }
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        var displayText = ""
        let variableName = variableDisplayText(key: variable, flowchart: flowchart)
        displayText += variableName.text
        if variableName.isSuccessful {
            let compType = ComparisonTypes(rawValue: storage[comparisonType] ?? 0)!
            // Successfully fetched the name of variable, display the value
            displayText += " \(compType.displayValue) "
            displayText += valueDisplayText(key: comparisonValue, flowchart: flowchart)
        }
        return displayText
    }
    
    static func createDefaultItem() -> IfElseItem {
        var item = IfElseItem()
        item.add(child: PlaceholderItem(), branch: .a)
        item.add(child: PlaceholderItem(), branch: .b)
        return item
    }
    
    var id = UUID()
    var storage = SettingValuesStorage()
    
    var renderer: FlowchartItemRenderer {
        // A - false, B - true
        let falseBranch = children.filter { $0.branch == .a }.map(\.item)
        let trueBranch = children.filter { $0.branch == .b }.map(\.item)
//        print("If/Else children: \(children)")
        return FlowchartItemRenderer(branchWithBase: self, a: falseBranch, b: trueBranch, labelA: "False", labelB: "True")
    }
    
    var variable: UUIDKey { "variable" }
    var comparisonType: IntKey { "compType" }
    var comparisonValue: ValuePicker.ValueKey { "compValue" }
    
    var settings: FlowchartItemSettings {
        VariablePicker(title: "Variable", variable: variable, allowedTypes: [.integer, .string])
        
        if storage[variable] != nil {
            EnumPicker(title: "Compare", selecting: ComparisonTypes.self, defaultValue: .equalsTo, value: comparisonType)
            
            ValuePicker(title: "Value", baseVariable: variable, valueKey: comparisonValue)
        }
    }
    
    func validateForExecution() throws {
        try validateVariable(key: variable)
        try validateValue(key: comparisonValue)
    }
    
    func execute(with runtime: FlowchartRuntime, completion: @escaping FlowchartRuntime.ExecuteCompletion, onInput: @escaping FlowchartRuntime.InputHandler) {
        do {
            let baseVariable = try VariablePicker.require(variable: variable, storage: storage, runtime: runtime)
            let comparison = try EnumPicker<ComparisonTypes>.get(value: comparisonType, storage: storage, defaultValue: .equalsTo)
            let value = try ValuePicker.getValue(from: runtime, baseVariable: baseVariable, storage: storage, key: comparisonValue)
            var shouldExecute = false
            if baseVariable.type == .integer {
                shouldExecute = try conditionalBranch(type: Int.self, base: baseVariable, compareWith: value, comparison: comparison)
            } else if baseVariable.type == .string {
                shouldExecute = try conditionalBranch(type: String.self, base: baseVariable, compareWith: value, comparison: comparison)
            }
            if shouldExecute {
                let trueBranch = children.filter { $0.branch == .b }.map(\.item)
                trueBranch.executeAll(with: runtime, completion: completion, onInput: onInput)
            } else {
                let falseBranch = children.filter { $0.branch == .a }.map(\.item)
                falseBranch.executeAll(with: runtime, completion: completion, onInput: onInput)
            }
        } catch {
            completion(.failure(error), self)
        }
    }
}

struct IfItem: FlowchartItem {
    var type: FlowchartItemType { .if }
    var shape: FlowchartShape { .diamond }
    var name: String { "If" }
    
    var usesChildren: Bool { true }
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        var displayText = ""
        let variableName = variableDisplayText(key: variable, flowchart: flowchart)
        displayText += variableName.text
        if variableName.isSuccessful {
            let compType = ComparisonTypes(rawValue: storage[comparisonType] ?? 0)!
            // Successfully fetched the name of variable, display the value
            displayText += " \(compType.displayValue) "
            displayText += valueDisplayText(key: comparisonValue, flowchart: flowchart)
        }
        return displayText
    }
    
    static func createDefaultItem() -> IfItem {
        var item = IfItem()
        // Only add placeholder to true branch
        item.add(child: PlaceholderItem())
        return item
    }
    
    var id = UUID()
    var storage = SettingValuesStorage()
    
    var renderer: FlowchartItemRenderer {
        // There's no actual branching going on, only rendering as a branching item
        return FlowchartItemRenderer(branchWithBase: self, a: [], b: childItems, labelA: "False", labelB: "True")
    }
    
    var variable: UUIDKey { "variable" }
    var comparisonType: IntKey { "compType" }
    var comparisonValue: ValuePicker.ValueKey { "compValue" }
    
    var settings: FlowchartItemSettings {
        VariablePicker(title: "Variable", variable: variable, allowedTypes: [.integer, .string])
        
        if storage[variable] != nil {
            EnumPicker(title: "Compare", selecting: ComparisonTypes.self, defaultValue: .equalsTo, value: comparisonType)
            
            ValuePicker(title: "Value", baseVariable: variable, valueKey: comparisonValue)
        }
    }
    
    func validateForExecution() throws {
        try validateVariable(key: variable)
        try validateValue(key: comparisonValue)
    }
    
    enum ExecutionError: LocalizedError {
        case unsupportedType
        
        var errorDescription: String? {
            switch self {
            case .unsupportedType: return "Type does not support comparison"
            }
        }
    }
    
    func execute(with runtime: FlowchartRuntime, completion: @escaping FlowchartRuntime.ExecuteCompletion, onInput: @escaping FlowchartRuntime.InputHandler) {
        do {
            let baseVariable = try VariablePicker.require(variable: variable, storage: storage, runtime: runtime)
            let comparison = try EnumPicker<ComparisonTypes>.get(value: comparisonType, storage: storage, defaultValue: .equalsTo)
            let value = try ValuePicker.getValue(from: runtime, baseVariable: baseVariable, storage: storage, key: comparisonValue)
            var shouldExecute = false
            if baseVariable.type == .integer {
                shouldExecute = try conditionalBranch(type: Int.self, base: baseVariable, compareWith: value, comparison: comparison)
            } else if baseVariable.type == .string {
                shouldExecute = try conditionalBranch(type: String.self, base: baseVariable, compareWith: value, comparison: comparison)
            }
            if shouldExecute {
                childItems.executeAll(with: runtime, completion: completion, onInput: onInput)
            } else {
                completion(.success(()), nil)
            }
        } catch {
            completion(.failure(error), self)
        }
    }
}

extension FlowchartItem {
    /// Figures out which branch it should execute
    /// - Returns: `true` to execute right branch, `false` to execute left branch
    func conditionalBranch<T>(type: T.Type, base: FlowchartRuntimeVariable, compareWith value: Any, comparison: ComparisonTypes) throws -> Bool where T: Comparable {
        guard let leftVal = base.value as? T, let rightVal = value as? T else {
            throw CommonExecutionError.typeMismatch
        }
        if comparison.execute(left: leftVal, right: rightVal) {
            return true
        } else {
            return false
        }
    }
}
