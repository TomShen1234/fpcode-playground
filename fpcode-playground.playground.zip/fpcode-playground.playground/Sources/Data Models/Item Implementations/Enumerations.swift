//
//  Enumerations.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/28.
//

import Foundation
import SwiftUI
import Combine

// MARK: - Comparison Enum
/// This enum has 3 values to indicate types of comparison.
/// It can be directly used in the `EnumPicker` setting item
enum ComparisonTypes: Int, EnumPickerSelectable {
    case equalsTo = 0
    case lessThan = 1
    case lessThanOrEqualTo = 2
    case greaterThanOrEqualTo = 3
    case greaterThan = 4
    
    var displayValue: String {
        switch self {
        case .lessThan: return "<"
        case .lessThanOrEqualTo: return "<="
        case .equalsTo: return "=="
        case .greaterThanOrEqualTo: return ">="
        case .greaterThan: return ">"
        }
    }
    
    func execute<T:Comparable>(left: T, right: T) -> Bool {
        switch self {
        case .equalsTo:
            return left == right
        case .lessThan:
            return left < right
        case .lessThanOrEqualTo:
            return left <= right
        case .greaterThanOrEqualTo:
            return left >= right
        case .greaterThan:
            return left > right
        }
    }
}

// MARK: - Operation Enum
/// This enum can select the operation to perform on a variable
enum OperationTypes: Int, EnumPickerSelectable {
    case add
    case subtract
    case multiply
    case divide
    case remainder
    
    var displayValue: String {
        switch self {
        case .add: return "+="
        case .subtract: return "-="
        case .multiply: return "*="
        case .divide: return "/="
        case .remainder: return "%="
        }
    }
    
    func execute(left: inout Int, right: Int) {
        switch self {
        case .add: left += right
        case .subtract: left -= right
        case .multiply: left *= right
        case .divide: left /= right
        case .remainder: left %= right
        }
    }
}
