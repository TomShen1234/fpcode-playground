//
//  IterationItems.swift
//  fpcode
//
//  Created by Tom Shen on 2021/4/3.
//

import Foundation
import SwiftUI
import Combine

// While/For loops

struct WhileLoopItem: FlowchartItem {
    var type: FlowchartItemType { .whileLoop }
    var shape: FlowchartShape { .diamond }
    var name: String { "While" }
    
    var usesChildren: Bool { true }
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        var displayText = ""
        let variableName = variableDisplayText(key: variable, flowchart: flowchart)
        displayText += variableName.text
        if variableName.isSuccessful {
            let compType = ComparisonTypes(rawValue: storage[comparisonType] ?? 0)!
            // Successfully fetched the name of variable, display the value
            displayText += " \(compType.displayValue) "
            displayText += valueDisplayText(key: comparisonValue, flowchart: flowchart)
        }
        return displayText
    }
    
    static func createDefaultItem() -> WhileLoopItem {
        var item = WhileLoopItem()
        item.add(child: PlaceholderItem())
        return item
    }
    
    var renderer: FlowchartItemRenderer {
        FlowchartItemRenderer(loopWithBase: self, items: childItems)
    }
    
    var id = UUID()
    var storage = SettingValuesStorage()
    
    var variable: UUIDKey { "variable" }
    var comparisonType: IntKey { "comparison" }
    var comparisonValue: ValuePicker.ValueKey { "compValue" }
    
    var settings: FlowchartItemSettings {
        VariablePicker(title: "Variable", variable: variable, allowedTypes: [.integer, .string])
        
        if storage[variable] != nil {
            EnumPicker(title: "Compare", selecting: ComparisonTypes.self, defaultValue: .equalsTo, value: comparisonType)
            
            ValuePicker(title: "Value", baseVariable: variable, valueKey: comparisonValue)
        }
    }
    
    func validateForExecution() throws {
        try validateVariable(key: variable)
        try validateValue(key: comparisonValue)
    }
    
    enum ExecutionError: LocalizedError {
        case tooManyIterations
        var errorDescription: String? {
            switch self {
            case .tooManyIterations: return "More than 1000 iterations ran"
            }
        }
    }
    
    func execute(with runtime: FlowchartRuntime, completion: @escaping FlowchartRuntime.ExecuteCompletion, onInput: @escaping FlowchartRuntime.InputHandler) {
        do {
            let baseVariable = try VariablePicker.require(
                variable: variable, storage: storage, runtime: runtime)
            let comparison = try EnumPicker<ComparisonTypes>.get(
                value: comparisonType, storage: storage, defaultValue: .equalsTo)
            let value = try ValuePicker.getValue(
                from: runtime, baseVariable: baseVariable, storage: storage, key: comparisonValue)

            let breakCondition = { (counter: Int) -> Result<Bool, Error> in
                Result {
                    if counter > 1000 {
                        // Do not allow more than 1000 iterations
                        throw ExecutionError.tooManyIterations
                    }
                    // From ConditionalItems.swift FlowchartItem extension
                    if baseVariable.type == .integer {
                        return try !conditionalBranch(type: Int.self, base: baseVariable, compareWith: value, comparison: comparison)
                    } else {
                        return try !conditionalBranch(type: String.self, base: baseVariable, compareWith: value, comparison: comparison)
                    }
                }
            }

            executeChildrenRecursively(
                runtime: runtime, completion: completion, breakCondition: breakCondition, onInput: onInput)
        } catch {
            completion(.failure(error), self)
        }
    }
}

struct ForLoopItem: FlowchartItem {
    var type: FlowchartItemType { .forLoop }
    var shape: FlowchartShape { .diamond }
    var name: String { "For" }
    
    var usesChildren: Bool { true }
    var children: [FlowchartItemContainer] = []
    
    func generateItemContent(for flowchart: Flowchart) -> String? {
        let variableName = variableDisplayText(key: loopVariable, flowchart: flowchart)
        var displayText = variableName.text
        if variableName.isSuccessful {
            displayText += "\n"
            displayText += iterationDisplayText(key: iterationSettings, flowchart: flowchart)
        }
        return displayText
    }
    
    static func createDefaultItem() -> ForLoopItem {
        var item = ForLoopItem()
        item.add(child: PlaceholderItem()) // Add a placeholder
        return item
    }
    
    var renderer: FlowchartItemRenderer {
        FlowchartItemRenderer(loopWithBase: self, items: childItems)
    }
    
    var loopVariable: UUIDKey { "loopVar" }
    var iterationSettings: IterationPicker.ValueKey { "iteration" }
    
    var id = UUID()
    var storage = SettingValuesStorage()
    
    var settings: FlowchartItemSettings {
        VariablePicker(title: "Loop Variable:", variable: loopVariable, allowedTypes: [.integer, .string])
        
        if storage[loopVariable] != nil {
            IterationPicker(title: "Iterate Using:", baseVariable: loopVariable, value: iterationSettings)
        }
    }
    
    func validateForExecution() throws {
        try validateVariable(key: loopVariable)
        // Iteration does not need validation
    }
    
    func execute(with runtime: FlowchartRuntime, completion: @escaping FlowchartRuntime.ExecuteCompletion, onInput: @escaping FlowchartRuntime.InputHandler) {
        do {
            let baseVariable = try VariablePicker.require(variable: loopVariable, storage: storage, runtime: runtime)
            // Get iteration
            let iterations = try IterationPicker.getIterations(from: runtime, base: baseVariable, value: iterationSettings, storage: storage)
            guard !iterations.isEmpty else {
                // Empty iteration array, pass
                completion(.success(()), nil)
                return
            }
            
            executeChildrenRecursively(runtime: runtime) { result, failureItem in
                // Make the trailing closure look good :)
                // Could just pass the handler block
                completion(result, failureItem)
            } breakCondition: { counter -> Result<Bool, Error> in
                .success(!iterations.indices.contains(counter))
            } onIncrement: { counter in
                baseVariable.value = iterations[counter]
            } onInput: { info, result in
                onInput(info, result)
            }
        } catch {
            completion(.failure(error), self)
        }
    }
}

fileprivate extension FlowchartItem {
    /// Executes all children recursively over and over. Until the break condition (base case) is met
    func executeChildrenRecursively(counter: Int = 0, runtime: FlowchartRuntime, completion: @escaping FlowchartRuntime.ExecuteCompletion, breakCondition: @escaping (Int) -> Result<Bool, Error>, onIncrement: ((Int) -> ())? = nil, onInput: @escaping FlowchartRuntime.InputHandler) {
        let shouldBreak: Bool
        do {
            try shouldBreak = breakCondition(counter).get()
        } catch {
            // Error getting break condition
            completion(.failure(error), self)
            return
        }
        
        if shouldBreak {
            // Base case, terminate
            completion(.success(()), nil)
        } else {
            // General case
            onIncrement?(counter) // Run the onIncrement first to perform any necessary changes
            childItems.executeAll(with: runtime) { result, failureItem in
                switch result {
                case .success(()):
                    // Next iteration
                    executeChildrenRecursively(counter: counter + 1, runtime: runtime, completion: completion, breakCondition: breakCondition, onIncrement: onIncrement, onInput: onInput)
                case .failure(let error):
                    // Failed, stop executing
                    completion(.failure(error), failureItem)
                }
            } onInput: { info, result in
                onInput(info, result)
            }
        }
    }
}
