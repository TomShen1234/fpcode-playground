//
//  Flowchart.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/14.
//

// The Flowchart struct is the content of the entire file.

import Foundation

// MARK: - Flowchart type
/// Stores the entire flowchart, is saved directly to file
struct Flowchart: Codable {
    var variables = [FlowchartVariable]()
    var items = [FlowchartItemContainer]()
    
    var displayItems: [FlowchartItem] {
        var allItems = items.map(\.item)
        
        // Generate begin and end item
        let startItem = StartEndItem(isStart: true)
        let endItem = StartEndItem(isStart: false)
        allItems.insert(startItem, at: 0)
        allItems.append(endItem)
        
        // Insert variable item if there are variables
        if !variables.isEmpty {
            let variableItem = VariableItem()
            allItems.insert(variableItem, at: 1)
        }
        
        return allItems
    }
    
    /// Find and get the variable object
    /// - Parameter id: The `UUID` to search for
    /// - Returns: The variable object if found, otherwise `nil`
    func getVariable(with id: UUID) -> FlowchartVariable? {
        return variables.first(where: { $0.id == id })
    }
    
    /// Add an item to the `items` array depending on current context
    /// - Parameters:
    ///   - item: The item to add
    ///   - selectedItem: The current selected item
    mutating func add(item: FlowchartItemContainer, after selectedItem: FlowchartItem?) {
        guard let selected = selectedItem else {
            // No item selected, add item at the end of root
            items.append(item)
            return
        }
        
        guard !selected.isGenerated else {
            // Generated item selected
            if let startEndItem = selected as? StartEndItem, startEndItem.isStart == false {
                // End item selected, add to end
                items.append(item)
            } else {
                // Start or variable selected, add to start
                items.insert(item, at: 0)
            }
            return
        }
        
        if let index = items.firstIndex(where: { $0.item.id == selected.id }) {
            // Found root item, insert after selected item
            items.insert(item, at: index + 1)
        } else {
            // Root item not found, traverse through tree and add if exists
            for index in items.indices {
                items[index].item.findAndAdd(item: item, after: selected)
            }
        }
    }
    
    mutating func delete(item id: UUID) {
        if let index = items.firstIndex(where: { $0.item.id == id }) {
            // Found root item, delete it
            items.remove(at: index)
        } else {
            // Root item not found, traverse through tree and remove if exists
            for index in items.indices {
                items[index].item.findAndDelete(target: id)
            }
        }
    }
    
    mutating func update(item: FlowchartItem) {
        if let index = items.firstIndex(where: { $0.item.id == item.id }) {
            // Found root item, delete it
            let branch = items[index].branch
            items[index] = FlowchartItemContainer(item: item, branch: branch)
        } else {
            // Root item not found, traverse through tree and remove if exists
            for index in items.indices {
                items[index].item.findAndUpdate(item: item)
            }
        }
    }
    
    func find(target: UUID) -> FlowchartItem? {
        if let container = items.first(where: { $0.item.id == target }) {
            return container.item
        } else {
            for container in items {
                if let foundItem = container.item.find(target: target) {
                    return foundItem
                }
            }
        }
        return nil
    }
    
    mutating func moveUp(target: UUID) {
        if let itemIndex = items.firstIndex(where: { $0.item.id == target }) {
            guard itemIndex != items.startIndex else { return }
            items.rearrange(from: itemIndex, to: itemIndex - 1)
        } else {
            for index in items.indices {
                if items[index].item.moveUp(target: target) {
                    // Done
                    return
                }
            }
        }
    }
    
    mutating func moveDown(target: UUID) {
        if let itemIndex = items.firstIndex(where: { $0.item.id == target }) {
            guard itemIndex != items.endIndex else { return }
            items.rearrange(from: itemIndex, to: itemIndex + 1)
        } else {
            for index in items.indices {
                if items[index].item.moveDown(target: target) {
                    // Done
                    return
                }
            }
        }
    }
}

// MARK: - Array helper
extension Array {
    mutating func rearrange(from fromIndex: Index, to toIndex: Index) {
        guard indices.contains(fromIndex) && indices.contains(toIndex) else { return }
        let element = self.remove(at: fromIndex)
        self.insert(element, at: toIndex)
    }
}
