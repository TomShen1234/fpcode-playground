//
//  ItemRendering.swift
//  fpcode
//
//  Created by Tom Shen on 2021/3/2.
//

import Foundation
import SwiftUI

struct FlowchartItemRenderer {
    enum RenderMode {
        case single
        case group
        case loop
        case branch
    }
    
    /// Which mode should the item be rendered
    private var renderMode: RenderMode
    /// Base item for use in single, loop and branch type
    private var baseItem: FlowchartItem?
    /// Array of items to render (see details for each type)
    private var items: [FlowchartItem]
    /// Array for the second branch of branch rendering
    private var secondBranchItems: [FlowchartItem]?
    /// Branch label for use in branch mode
    private var branchLabels: (String, String)?
    
    init(singleItem item: FlowchartItem) {
        self.renderMode = .single
        self.baseItem = item
        self.items = []
        self.secondBranchItems = nil
        self.branchLabels = nil
    }
    
    init(groupOf items: [FlowchartItem]) {
        self.renderMode = .group
        self.baseItem = nil
        self.items = items
        self.secondBranchItems = nil
        self.branchLabels = nil
    }
    
    init(loopWithBase base: FlowchartItem, items: [FlowchartItem]) {
        self.renderMode = .loop
        self.baseItem = base
        self.items = items
        self.secondBranchItems = nil
        self.branchLabels = nil
    }
    
    init(branchWithBase base: FlowchartItem, a: [FlowchartItem], b: [FlowchartItem], labelA: String, labelB: String) {
        self.renderMode = .branch
        self.baseItem = base
        self.items = a
        self.secondBranchItems = b
        self.branchLabels = (labelA, labelB)
    }
    
    // MARK: - Render Functions
    
    typealias ItemAction = FlowchartItemView.ItemAction
    
    @ViewBuilder func render(for flowchart: Flowchart, selection: Binding<FlowchartItem?>, itemAction: @escaping ItemAction) -> some View {
        switch renderMode {
        case .single: renderSingle(flowchart, selection, itemAction)
        case .group: renderGroup(flowchart, selection, itemAction)
        case .loop: renderLoop(flowchart, selection, itemAction)
        case .branch: renderBranch(flowchart, selection, itemAction)
        }
    }
    
    private func renderSingle(_ flowchart: Flowchart, _ selection: Binding<FlowchartItem?>, _ itemAction: @escaping ItemAction) -> some View {
        // The single item is the only one that actually gets rendered
        // All other will recursively create more renderers
        return FlowchartItemView(chart: flowchart, item: baseItem!, selection: selection, itemAction: itemAction)
    }
    
    private func renderGroup(_ flowchart: Flowchart, _ selection: Binding<FlowchartItem?>, _ itemAction: @escaping ItemAction) -> some View {
        return FlowchartItemGroup(flowchart: flowchart, items: items, selectedItem: selection, itemAction: itemAction)
    }
    
    private func renderLoop(_ flowchart: Flowchart, _ selection: Binding<FlowchartItem?>, _ itemAction: @escaping ItemAction) -> some View {
        return FlowchartLoopGroup(flowchart: flowchart, base: baseItem!, loopItems: items, selection: selection, itemAction: itemAction)
    }
    
    private func renderBranch(_ flowchart: Flowchart, _ selection: Binding<FlowchartItem?>, _ itemAction: @escaping ItemAction) -> some View {
        return FlowchartBranchGroup(flowchart: flowchart, base: baseItem!, firstItems: items, secondItems: secondBranchItems!, branchLabels: branchLabels!, selection: selection, itemAction: itemAction)
    }
}

// MARK: - Single Item
// Single item can be found in FlowchartViews.swift

// MARK: - Group Item
// Group item can be found in FlowchartViews.swift

// MARK: - Loop Item
fileprivate struct FlowchartLoopGroup: View {
    var flowchart: Flowchart
    
    var base: FlowchartItem
    var loopItems: [FlowchartItem]
    
    @Binding var selection: FlowchartItem?
    
    typealias ItemAction = FlowchartItemView.ItemAction
    var itemAction: ItemAction
    
    var body: some View {
        VStack(spacing: 2) {
            // Force base to be rendered as single item
            let baseRenderer = FlowchartItemRenderer(singleItem: base)
            baseRenderer.render(for: flowchart, selection: $selection, itemAction: itemAction)
            
            FlowchartLine()
                .frame(height: 40)
            
            FlowchartItemGroup(flowchart: flowchart, items: loopItems, selectedItem: $selection, itemAction: itemAction)
            
            if !loopItems.isEmpty {
                FlowchartLine()
                    .frame(height: 40)
            }
            
            Circle()
                .stroke(Color.primary, lineWidth: 3)
                .frame(width: 20, height: 20)
        }
        .overlay(loopView)
        .padding(.horizontal)
    }
    
    var loopView: some View {
        HStack(spacing: 0) {
            // For padding
            loopLine.hidden()
            loopLine
        }
    }
    
    var loopLine: some View {
        GeometryReader { geometry in
            Path { path in
                let width = geometry.size.width
                let height = geometry.size.height
                let circleRadius: CGFloat = 10
                let itemWidth: CGFloat = 190
                let itemHeight: CGFloat = 63
                path.move(to: CGPoint(x: circleRadius, y: height - circleRadius))
                path.addLine(to: CGPoint(x: width, y: height - circleRadius))
                path.addLine(to: CGPoint(x: width, y: itemHeight))
                path.addLine(to: CGPoint(x: itemWidth / 2, y: itemHeight))
            }
            .stroke(Color.secondary, lineWidth: 3)
        }
    }
}

// MARK: - Branch Item
fileprivate struct LeftColumnSizeReaderKey: SizeReaderKey {
    static var defaultValue: CGSize = .zero
}

fileprivate struct RightColumnSizeReaderKey: SizeReaderKey {
    static var defaultValue: CGSize = .zero
}

fileprivate struct FlowchartBranchGroup: View {
    var flowchart: Flowchart
    
    var base: FlowchartItem
    var firstItems: [FlowchartItem]
    var secondItems: [FlowchartItem]
    var branchLabels: (String, String)
    
    @Binding var selection: FlowchartItem?
    
    typealias ItemAction = FlowchartItemView.ItemAction
    var itemAction: ItemAction
    
    @State private var leftColumnWidth: CGFloat = 0
    @State private var rightColumnWidth: CGFloat = 0
    
    private var itemWidth: CGFloat { 190 }
    
    // Fix size reader inconsistency
    @State private var extraPadding: CGFloat = 0
    
    private var leftPadding: CGFloat {
        if leftColumnWidth < rightColumnWidth {
            return (rightColumnWidth - leftColumnWidth) / 2
        } else {
            return 0
        }
    }
    
    private var rightPadding: CGFloat {
        if rightColumnWidth < leftColumnWidth {
            return (leftColumnWidth - rightColumnWidth) / 2
        } else {
            return 0
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Force base to be rendered as single item
            let baseRenderer = FlowchartItemRenderer(singleItem: base)
            baseRenderer.render(for: flowchart, selection: $selection, itemAction: itemAction)
            
            HStack(alignment: .top, spacing: 20) {
                // Left
                VStack(spacing: 2) {
                    FlowchartItemGroup(flowchart: flowchart, items: firstItems, selectedItem: $selection, itemAction: itemAction)
                        .padding(.horizontal, extraPadding) // See fixSizeReader()
                    
                    FlowchartLine()
                        .frame(width: 3)
                        .frame(minHeight: 0, idealHeight: 0)
                }
                .onSizeChanged(LeftColumnSizeReaderKey.self) { leftSize in
                    leftColumnWidth = leftSize.width
//                    print("Left \(leftColumnWidth)")
                }
                .padding(.horizontal, leftPadding)
                
                // Right
                VStack(spacing: 2) {
                    FlowchartItemGroup(flowchart: flowchart, items: secondItems, selectedItem: $selection, itemAction: itemAction)
                        .padding(.horizontal, extraPadding) // See fixSizeReader()
                    
                    FlowchartLine()
                        .frame(width: 3)
                        .frame(minHeight: 0, idealHeight: 0)
                }
                .onSizeChanged(RightColumnSizeReaderKey.self) { rightSize in
                    rightColumnWidth = rightSize.width
//                    print("Right \(rightColumnWidth)")
                }
                .padding(.horizontal, rightPadding)
            }
            
            Circle()
                .stroke(Color.primary, lineWidth: 3)
                .frame(width: 20, height: 20)
                .padding(.top, 30)
        }
        .overlay(branches)
        .onAppear {
            fixSizeReader()
        }
    }
    
    /// Increase the padding by a point to force the size reader to update
    /// because sometimes it doesn't trigger (SwiftUI bug?)
    private func fixSizeReader() {
        delay(seconds: 0.01) {
            // Adds some padding to force a change in size of the view
            extraPadding = 1
        }
    }
    
    @ViewBuilder var branches: some View {
        GeometryReader { outerGeo in
            VStack {
                makeTopBranch(outerGeo)
                
                Spacer()
                
                makeBottomBranch(outerGeo)
            }
        }
    }
    
    @ViewBuilder private var branchLabelView: some View {
        let itemWidth: CGFloat = 190
        HStack {
            Text(branchLabels.0)
                .padding(.trailing, itemWidth + 25)
            
            Text(branchLabels.1)
        }
        .padding(.top, 30)
    }
    
    @ViewBuilder private func makeTopBranch(_ geometry: GeometryProxy) -> some View {
        let itemHeight: CGFloat = 65
        let columnWidth = max(leftColumnWidth, rightColumnWidth)
        let branchWidth = columnWidth == 0 ? geometry.size.width / 10 : (columnWidth / 2) - (itemWidth / 2) + 10
        
        HStack(spacing: 0) {
            Spacer()
            GeometryReader { geometry in
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height - 1 // Fix a small overlap
                    path.move(to: CGPoint(x: 0, y: height))
                    path.addLine(to: CGPoint(x: 0, y: 0))
                    path.addLine(to: CGPoint(x: width, y: 0))
                }
                .stroke(Color.secondary, lineWidth: 3)
            }
            .frame(width: branchWidth)
            .padding(.trailing, itemWidth)
            
            GeometryReader { geometry in
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height
                    path.move(to: CGPoint(x: 0, y: 0))
                    path.addLine(to: CGPoint(x: width, y: 0))
                    path.addLine(to: CGPoint(x: width, y: height))
                }
                .stroke(Color.secondary, lineWidth: 3)
            }
            .frame(width: branchWidth)
            Spacer()
        }
        .frame(height: itemHeight)
        .padding(.top, itemHeight / 2 + 30)
        .overlay(branchLabelView, alignment: .top)
    }
    
    @ViewBuilder private func makeBottomBranch(_ geometry: GeometryProxy) -> some View {
        let circleRadius: CGFloat = 10
        let circleTopPadding: CGFloat = 30
        let columnWidth = max(leftColumnWidth, rightColumnWidth)
        let branchWidth = columnWidth == 0 ? geometry.size.width / 10 : (columnWidth / 2) - (circleRadius / 2) + 5
        
        HStack(spacing: 0) {
            GeometryReader { geometry in
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height
                    path.move(to: CGPoint(x: 0, y: 0))
                    path.addLine(to: CGPoint(x: 0, y: height))
                    path.addLine(to: CGPoint(x: width, y: height))
                }
                .stroke(Color.secondary, lineWidth: 3)
            }
            .frame(width: branchWidth)
            .padding(.trailing, circleRadius * 2)
            
            GeometryReader { geometry in
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height
                    path.move(to: CGPoint(x: 0, y: height))
                    path.addLine(to: CGPoint(x: width, y: height))
                    path.addLine(to: CGPoint(x: width, y: 0))
                }
                .stroke(Color.secondary, lineWidth: 3)
            }
            .frame(width: branchWidth)
        }
        .frame(height: circleRadius + circleTopPadding)
        .padding(.bottom, circleRadius)
    }
}
