//
//  FlowchartExecution.swift
//  fpcode
//
//  Created by Tom Shen on 2021/4/3.
//

import Foundation
import SwiftUI
import Combine

// MARK: - Runtime Storage

/// Stores the runtime of flowchart execution
class FlowchartRuntime {
    /// Execute when the flowchart finished running
    typealias ExecuteCompletion = (_ result: Result<Void, Error>, _ failureItem: FlowchartItem?) -> ()
    /// Execute when the flowchart needs to request for data
    typealias InputHandler = (_ info: FlowchartRuntimeVariable.Info, _ completion: @escaping InputHandlerCompletion) -> ()
    /// Call this block to send the returned data back to the flowchart to continue execution
    typealias InputHandlerCompletion = (_ input: String) -> ()
    
    var variables: [FlowchartRuntimeVariable]
    var output: String
    
    init(initialVariables: [FlowchartVariable]) {
        variables = initialVariables.map(FlowchartRuntimeVariable.init)
        output = ""
    }
    
    func variable(with id: UUID) -> FlowchartRuntimeVariable? {
        return variables.first(where: { $0.id == id })
    }
    
    func output(_ text: String) {
        if !output.isEmpty {
            // Not empty, add a newline
            output += "\n"
        }
        output += text
    }
}

/// Manages a variable of flowchart execution runtime
class FlowchartRuntimeVariable {
    var id: UUID
    var name: String
    var type: FlowchartVariable.VariableType
    var value: Any
    
    init(id: UUID, name: String, type: FlowchartVariable.VariableType, value: Any) {
        self.id = id
        self.name = name
        self.value = value
        self.type = type
    }
    
    init(from variable: FlowchartVariable) {
        self.id = variable.id
        self.name = variable.name
        self.type = variable.type
        switch variable.type {
        case .integer: value = variable.getIntegerValue()
        case .string: value = variable.getStringValue()
        case .intArray: value = variable.getArrayValue(of: Int.self)
        case .stringArray: value = variable.getArrayValue(of: String.self)
        }
    }
    
    var isArray: Bool {
        return type == .intArray || type == .stringArray
    }
    
    var info: Info {
        Info(name: name, type: type)
    }
    
    /// Simplified version that only contains the name and the type
    struct Info {
        var name: String
        var type: FlowchartVariable.VariableType
    }
}

// MARK: - Execution
extension Flowchart {
    /// The completion handler for `execute`.
    /// - Parameter result: The result of the execution
    /// - Parameter failureItem: If the execution fails, the item that it failed on will be passed into this parameter
    typealias ExecutionCompletion = (_ result: Result<String, Error>, _ failureItem: FlowchartItem?) -> ()
    typealias InputHandler = FlowchartRuntime.InputHandler
    
    /// Execute the flowchart, returning the result in a closure
    /// - Parameter completion: The completion handler.
    func execute(completion: @escaping ExecutionCompletion, onInput: @escaping InputHandler) {
        guard !items.isEmpty else {
            // No item to execute, complete immediately
            completion(.success(""), nil)
            return
        }
        
        // Validate items
        for container in items {
            let validationResult = container.item.performValidation()
            if case .failure(let error) = validationResult.result {
                // Validation failed
                completion(.failure(error), validationResult.failureItem)
                return
            }
        }
        
        // Create a runtime and start executing
        let runtime = FlowchartRuntime(initialVariables: variables)
        recursiveExecuteItem(at: 0, runtime: runtime, completion: completion, onInput: onInput)
    }
    
    /// Recursive implementation of `execute`
    private func recursiveExecuteItem(at index: Int, runtime: FlowchartRuntime, completion: @escaping ExecutionCompletion, onInput: @escaping InputHandler) {
        guard index < items.count else {
            // No more item: call success
            completion(.success(runtime.output), nil)
            return
        }
        
        let itemContainer = items[index]
        itemContainer.item.execute(with: runtime) { itemResult, failureItem in
            // Item execution completion handler
            switch itemResult {
            case .success:
                // Item executed successfully, recursively execute the next one
                recursiveExecuteItem(at: index + 1, runtime: runtime, completion: completion, onInput: onInput)
            case .failure(let error):
                // Item execution failed, execute the next one
                completion(.failure(error), failureItem)
            }
        } onInput: { type, completionHandler in
            onInput(type, completionHandler)
        }
    }
}

// MARK: - Common Error Types
enum CommonValidationError: LocalizedError {
    case missingVariable
    case missingValue
    case missingComparison
    case missingOperation
    
    var errorDescription: String? {
        switch self {
        case .missingVariable: return "Missing variable"
        case .missingValue: return "Missing value"
        case .missingComparison: return "Missing comparison"
        case .missingOperation: return "Missing operation"
        }
    }
}

enum CommonExecutionError: LocalizedError {
    case cannotGetID
    case cannotFindVariable
    case typeMismatch
    
    case arrayTypeMismatch
    case arrayIndexOutOfBounds
    case invalidArrayIndexType
    
    var errorDescription: String? {
        switch self {
        case .cannotGetID: return "Error finding variable ID within internal storage"
        case .cannotFindVariable: return "Error finding variable within runtime"
        case .typeMismatch: return "Assigning value with invalid type"
        case .arrayTypeMismatch: return "Assigning value with array of invalid type"
        case .arrayIndexOutOfBounds: return "Array index out of bounds"
        case .invalidArrayIndexType: return "Array index variable must be integer"
        }
    }
}

// MARK: - Settings + Validation
// MARK: Value Picker
extension ValuePickerSettingItem {
    enum ValidationError: LocalizedError {
        case missingCustomValue
        
        var errorDescription: String? {
            switch self {
            case .missingCustomValue: return "Missing custom value"
            }
        }
    }
}

extension FlowchartItem {
    /// Validation for `ValuePicker`
    func validateValue(key: ValuePicker.ValueKey) throws {
        // First - A UUID to the variable for the value (default: Custom).
        // Second - A String value for the custom field.
        // Third - A flag indicating whether an array is used to pick single value.
        // Fourth - An UUID to the variable for the index of array value. (default: Custom)
        // Fifth - The index of the single value in the array.
        if storage[key.first] == nil {
            // Custom value
            if storage[key.second] == nil {
                // No custom value
                throw ValuePicker.ValidationError.missingCustomValue
            }
        }
    }
    
    /// Validation for `VariablePicker`
    func validateVariable(key: UUIDKey) throws {
        if storage[key] == nil {
            throw CommonValidationError.missingVariable
        }
    }
}

// MARK: - Settings + Execution
// MARK: Variable Picker
extension VariablePicker {
    /// Requires the variable to be present in storage and runtime, and return it
    static func require(variable variableKey: UUIDKey, storage: SettingValuesStorage, runtime: FlowchartRuntime) throws -> FlowchartRuntimeVariable {
        guard let targetVariableID = storage[variableKey] else {
            throw CommonExecutionError.cannotGetID
        }
        guard let variable = runtime.variable(with: targetVariableID) else {
            throw CommonExecutionError.cannotFindVariable
        }
        return variable
    }
}

// MARK: Index Picker
extension IndexPicker {
    static func getIndex(runtime: FlowchartRuntime, storage: SettingValuesStorage, key: ValueKey) throws -> Int {
        if let targetIndexID = storage[key.first] {
            // Assigning index with variable
            guard let targetIndexVariable = runtime.variable(with: targetIndexID) else {
                throw ValuePicker.ExecutionError.noIndexVariable
            }
            
            guard targetIndexVariable.type == .integer else {
                // Type mismatch. Validation bug?
                throw CommonExecutionError.invalidArrayIndexType
            }
            
            return targetIndexVariable.value as! Int
        } else {
            // Assigning fixed index
            // Index default to 0
            return storage[key.second] ?? 0
        }
    }
}

// MARK: Value Picker
extension ValuePicker {
    enum ExecutionError: LocalizedError {
        case noCustomValue
        case noIndexVariable
        
        case noCustomIndex
        
        var errorDescription: String? {
            switch self {
            case .noCustomValue: return "Custom value cannot be found"
            case .noIndexVariable: return "Cannot find variable for array index"
            case .noCustomIndex: return "Custom index cannot be found"
            }
        }
    }
    
    /// Get the value selected by a `ValuePicker` from runtime
    ///
    /// **IMPORTANT**: This method is not type safe, validate type before proceeding
    static func getValue(from runtime: FlowchartRuntime, baseVariable variable: FlowchartRuntimeVariable, storage: SettingValuesStorage, key valueKey: ValueKey) throws -> Any {
        if let targetVarID = storage[valueKey.first] {
            // Assigning a value from another variable
            guard let targetVariable = runtime.variable(with: targetVarID) else {
                // Cannot find target variable
                throw CommonExecutionError.cannotFindVariable
            }
            
            if !variable.isArray && targetVariable.isArray {
                // Fetching array values (ex. value = target[index])
                guard (variable.type == .integer && targetVariable.type == .intArray) || (variable.type == .string && targetVariable.type == .stringArray) else {
                    // Invalid array type. Validation Bug?
                    throw CommonExecutionError.arrayTypeMismatch
                }
                
                let indexKey = IndexPicker.ValueKey(first: valueKey.fourth, second: valueKey.fifth)
                let assignIndex = try IndexPicker.getIndex(runtime: runtime, storage: storage, key: indexKey)
                
                // Return the value from the array
                let arrayValue = targetVariable.value as! [Any]
                guard arrayValue.indices.contains(assignIndex) else {
                    throw CommonExecutionError.arrayIndexOutOfBounds
                }
                
                return arrayValue[assignIndex]
            } else {
                // Assigning single value to single value
                // TODO: Reenable this check using projected value
//                guard variable.type == targetVariable.type else {
//                    // Type mismatch. Validation bug?
//                    throw CommonExecutionError.typeMismatch
//                }
                
                return targetVariable.value
            }
        } else {
            // Assigning to custom value
            guard let customValue = storage[valueKey.second] else {
                // Cannot find custom value. Validation bug?
                throw ValuePicker.ExecutionError.noCustomValue
            }
            
            switch variable.type {
            case .integer: return Int(customValue) ?? 0
            case .string: return customValue
            case .intArray: return try [Int].decode(from: customValue)
            case .stringArray: return try [String].decode(from: customValue)
            }
        }
    }
}

// MARK: Enum Picker
extension EnumPicker {
    enum ExecutionError: LocalizedError {
        case missingValue
        case invalidCaseValue
        
        var errorDescription: String? {
            switch self {
            case .missingValue: return "Missing enum value"
            case .invalidCaseValue: return "Invalid case value"
            }
        }
    }
    
    /// Get the value of `EnumPicker`
    static func get(value valueKey: IntKey, storage: SettingValuesStorage, defaultValue: EnumType? = nil) throws -> EnumType {
        guard let value = storage[valueKey] else {
            if let def = defaultValue { return def }
            throw ExecutionError.missingValue
        }
        
        guard let result = EnumType(rawValue: value) else {
            if let def = defaultValue { return def }
            throw ExecutionError.invalidCaseValue
        }
        
        return result
    }
}

// MARK: Iteration Picker
extension IterationPicker {
    enum ExecutionError: LocalizedError {
        case cannotCreateArray
        
        var errorDescription: String? {
            switch self {
            case .cannotCreateArray: return "Error creating iteration"
            }
        }
    }
    
    /// Get the iteration values selected by a `IterationPicker` from runtime
    ///
    /// **IMPORTANT**: This method is not type safe, validate type before proceeding
    static func getIterations(from runtime: FlowchartRuntime, base: FlowchartRuntimeVariable, value key: ValueKey, storage: SettingValuesStorage) throws -> [Any] {
        // 1. Array Variable (nil to use integer range) 2. Int Lowerbound, 3. Int Upperbound
        if let iterationVarID = storage[key.first] {
            // Iterating an array
            guard let variable = runtime.variable(with: iterationVarID) else {
                throw CommonExecutionError.cannotFindVariable
            }
            // Check array type
            guard (base.type == .integer && variable.type == .intArray) || (base.type == .string && variable.type == .stringArray) else {
                throw CommonExecutionError.arrayTypeMismatch
            }
            guard let iterationArray = variable.value as? [Any] else {
                throw ExecutionError.cannotCreateArray
            }
            return iterationArray
        } else {
            guard base.type == .integer else {
                throw CommonExecutionError.arrayTypeMismatch
            }
            let lowerbounds = storage[key.second] ?? 0
            let upperbounds = storage[key.third] ?? 0
            return Array(lowerbounds...upperbounds)
        }
    }
}

// MARK: Set Value Picker
extension SetValuePicker {
    enum ExecutionError: LocalizedError {
        case notArray
        var errorDescription: String? {
            switch self {
            case .notArray: return "Using array assign to assign to non-array"
            }
        }
    }
    
    /// Assign the `assignValue` into the array at index specified in the key.
    static func assignToArray(runtime: FlowchartRuntime, key: ValueKey, variable: FlowchartRuntimeVariable, settings: SettingValuesStorage, assignValue: Any) throws {
        // Get array and index, check for index validity, and assign
        guard var array = variable.value as? [Any] else { throw ExecutionError.notArray }
        let indexKey = IndexPicker.ValueKey(first: key.third, second: key.fourth)
        let index = try IndexPicker.getIndex(runtime: runtime, storage: settings, key: indexKey)
        guard array.indices.contains(index) else { throw CommonExecutionError.arrayIndexOutOfBounds }
        array[index] = assignValue
        variable.value = array
    }
}

// MARK: - Array + Execution
extension Array where Element == FlowchartItem {
    typealias ExecuteCompletion = FlowchartRuntime.ExecuteCompletion
    typealias InputHandler = FlowchartRuntime.InputHandler
    
    /// Execute all flowchart items within this array in order
    func executeAll(with runtime: FlowchartRuntime, completion: @escaping ExecuteCompletion, onInput: @escaping InputHandler) {
        executeItem(with: runtime, at: 0, completion: completion, onInput: onInput)
    }
    
    private func executeItem(with runtime: FlowchartRuntime, at index: Int, completion: @escaping ExecuteCompletion, onInput: @escaping InputHandler) {
        guard self.indices.contains(index) else {
            // Base case, no more item, execution finished
            completion(.success(()), nil)
            return
        }
        
        // General case, execute and execute next one
        let item = self[index]
        item.execute(with: runtime) { result, failureItem in
            switch result {
            case .success:
                executeItem(with: runtime, at: index + 1, completion: completion, onInput: onInput)
            case .failure(let error):
                completion(.failure(error), failureItem)
            }
        } onInput: { info, result in
            onInput(info, result)
        }
    }
}

// MARK: Array decode
extension Array where Element: FlowchartVariableDataType {
    enum DecodeError: LocalizedError {
        case cannotDecodeArray
        var errorDescription: String? {
            switch self {
            case .cannotDecodeArray: return "Input array cannot be decoded"
            }
        }
    }
    /// Helper function that decodes value from String based input
    static func decode(from rawValue: String) throws -> [Element] {
        let data = Data(rawValue.utf8)
        do {
            return try JSONDecoder().decode([Element].self, from: data)
        } catch {
            throw DecodeError.cannotDecodeArray
        }
    }
}
