//
//  SettingItems.swift
//  fpcode
//
//  Created by Tom Shen on 2021/3/19.
//

import SwiftUI
import Foundation

// MARK: - Variable Picker

/// A setting item that allows a variable to be selected.
typealias VariablePicker = VariablePickerSettingItem
struct VariablePickerSettingItem: SettingItem {
    var title: String
    
    var variable: UUIDKey
    
    var allowedTypes: [FlowchartVariable.VariableType]? = nil
    
    func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        let modifyBinding = settings.uuidValue(variable)
        Picker(title, selection: modifyBinding) {
            Text("[select]").tag(nil as UUID?)
            
            let iterateVariables = allowedTypes != nil ? flowchart.variables.filter { allowedTypes!.contains($0.type) } : flowchart.variables
            ForEach(iterateVariables) { variable in
                Text(variable.name)
                    .tag(variable.id as UUID?)
            }
        }
    }
}

extension FlowchartItem {
    /// Helper function to get a displayable name of variable from setting storage
    func variableDisplayText(key: UUIDKey, flowchart: Flowchart) -> (text: String, isSuccessful: Bool) {
        if let variableID = self.storage[key] {
            if let selectedVar = flowchart.getVariable(with: variableID) {
                return (selectedVar.name, true)
            } else {
                return ("Unknown Variable", false)
            }
        } else {
            return ("Select Variable", false)
        }
    }
}

// MARK: - Value Picker
// TODO: Support null in a later version
/// A setting item that allows selecting an appropriate value to a variable
typealias ValuePicker = ValuePickerSettingItem
struct ValuePickerSettingItem: SettingItem {
    var title: String
    
    /// A key to the variable which the value type will be determined
    var baseVariable: UUIDKey
    
    var setValueBase: SetValuePicker.ValueKey? = nil
    
    /// First - A UUID to the variable for the value (default: Custom).
    /// Second - A String value for the custom field.
    /// Third - A flag indicating whether an array is used to pick single value.
    /// Fourth - An UUID to the variable for the index of array value. (default: Custom)
    /// Fifth - The index of the single value in the array.
    typealias ValueKey = HybridSettingsKey5<UUIDKey, StringKey, IntKey, UUIDKey, IntKey>
    var valueKey: ValueKey
    
    func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        let variableBinding = settings.uuidValue(valueKey.first)
        let arrayChosen = settings.intValue(valueKey.third)
            
        Picker(title, selection: variableBinding) {
            Text("Custom").tag(nil as UUID?)
            
            Divider()
            
            // Make sure the base variable is actually selected (non-nil)
            if let baseVariableValue = settings.wrappedValue[baseVariable],
               let variable = flowchart.getVariable(with: baseVariableValue) {
                // If the projected value type is used, we need to adjust the filter type accordingly
                let filterType = getProjectedType(variable, settings, flowchart)
                
                // Filter rules: 1. Not itself 2. Same value type
                let filteredVariable = flowchart.variables.filter { $0.id != baseVariableValue && $0.type == filterType }
                ForEach(filteredVariable) { variable in
                    Text(variable.name)
                        .tag(variable.id as UUID?)
                }
                
                // Get array with same type
                if [.integer, .string].contains(filterType) {
                    Divider()

                    let filteredArrayValue = flowchart.variables.filter {
                        let filterType: FlowchartVariable.VariableType = variable.type == .integer ? .intArray : .stringArray
                        return $0.type == filterType
                    }

                    ForEach(filteredArrayValue) { variable in
                        Text("Array: " + variable.name)
                            .tag(variable.id as UUID?)
                    }
                }
            }
        }
        .onChange(of: variableBinding.wrappedValue) { newID in
            if let id = newID,
               let variable = flowchart.getVariable(with: id),
               variable.isArray,
               let baseID = settings.wrappedValue[baseVariable],
               let baseVariable = flowchart.getVariable(with: baseID),
               ![.stringArray, .intArray].contains(getProjectedType(baseVariable, settings, flowchart)) {
                // An array is chosen when the base is not an array
                arrayChosen.wrappedValue = 1
            } else {
                arrayChosen.wrappedValue = 0
            }
        }
        
        if variableBinding.wrappedValue == nil {
            // Custom selected
            let stringBinding = settings.stringValue(valueKey.second).unwrap(default: "")
            TextField("Custom \(title)", text: stringBinding)
        }
        
        if arrayChosen.wrappedValue == 1 {
            // Display a value picker to choose the index
            let indexKey = IndexPicker.ValueKey(first: valueKey.fourth, second: valueKey.fifth)
            IndexPicker(title: "Index", baseVariable: baseVariable, value: indexKey)
                .generateView(for: flowchart, settings: settings)
        }
    }
    
    private func getProjectedType(_ variable: FlowchartVariable, _ settings: Binding<SettingValuesStorage>, _ flowchart: Flowchart) -> FlowchartVariable.VariableType {
        let type = setValueBase != nil
            ? SetValuePicker.projectedType(key: setValueBase!, settings: settings.wrappedValue, flowchart: flowchart) ?? variable.type
            : variable.type
        return type
    }
}

extension FlowchartItem {
    /// Helper function to get a displayable name of variable from setting storage
    func valueDisplayText(key: ValuePicker.ValueKey, flowchart: Flowchart) -> String {
        let variableKey = key.first
        if storage[variableKey] == nil {
            // Custom value
            if let customValue = storage[key.second] {
                // TODO: Optimize to display data types
                return customValue
            } else {
                return "No value"
            }
        } else {
            let variableName = variableDisplayText(key: variableKey, flowchart: flowchart)
            if variableName.isSuccessful {
                if storage[key.third] == 1 {
                    // Array is selected for int/string values, display the index
                    let indexKey = IndexPicker.ValueKey(first: key.fourth, second: key.fifth)
                    return indexPickerLabel(baseVariableName: variableName.text, index: indexKey, flowchart: flowchart)
                } else {
                    return variableName.text
                }
            } else {
                return "Error"
            }
        }
    }
}

// MARK: - Text Field

/// A setting item that allows a string to be entered
typealias TextSetting = TextFieldSettingItem
struct TextFieldSettingItem: SettingItem {
    var title: String
    
    var text: StringKey
    
    func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        let modifyBinding = settings.stringValue(text).unwrap(default: "")
        TextField(title, text: modifyBinding)
            .labelsHidden()
    }
}

// MARK: - Enum Picker
/// Conform to this protocol to allow the enum to be selectable
protocol EnumPickerSelectable: RawRepresentable, CaseIterable, Hashable {
    /// Return a string for each case to display to user
    var displayValue: String { get }
}

/// A setting item that allows a value from an enum to be selected.
///
/// The enum must conform to `EnumPickerSelectable` and have  `Int` raw value
typealias EnumPicker = EnumPickerSettingItem
struct EnumPickerSettingItem<EnumType>: SettingItem where EnumType: EnumPickerSelectable, EnumType.AllCases: RandomAccessCollection, EnumType.RawValue == Int {
    var title: String
    var selecting: EnumType.Type
    var defaultValue: EnumType
    var value: IntKey
    
    func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        let valueBinding = settings.intValue(value).unwrap(default: defaultValue.rawValue)
        Picker(title, selection: valueBinding) {
            ForEach(selecting.allCases, id: \.self) { value in
                Text(value.displayValue).tag(value.rawValue)
            }
        }
    }
}

// MARK: - Iteration Picker
/// A setting item that creates an iteration, commonly used for 'for' loops.
typealias IterationPicker = IterationPickerSettingItem
struct IterationPickerSettingItem: SettingItem {
    var title: String
    
    /// A key to the variable which the value type will be determined.
    ///
    /// This can only be integer or string variable.
    var baseVariable: UUIDKey
    
    /// 1. Array Variable (nil to use integer range) 2. Int Lowerbound, 3. Int Upperbound
    typealias ValueKey = HybridSettingsKey3<UUIDKey, IntKey, IntKey>
    var value: ValueKey
    
    func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        if let baseVariableValue = settings.wrappedValue[baseVariable],
           let baseVariable = flowchart.getVariable(with: baseVariableValue),
           [.integer, .string].contains(baseVariable.type) {
            // Variable supports looping, setup picker
            let variableBinding = settings.uuidValue(value.first)
            Picker(title, selection: variableBinding) {
                if baseVariable.type == .integer {
                    // Integer base selected
                    Text("Custom Range").tag(nil as UUID?)
                    
                    Divider()
                    
                    // Int arrays can also be looped
                    let intArrays = flowchart.variables.filter { $0.type == .intArray }
                    ForEach(intArrays) { item in
                        Text(item.name).tag(item.id as UUID?)
                    }
                } else {
                    // String base selected
                    let stringArrays = flowchart.variables.filter { $0.type == .stringArray }
                    ForEach(stringArrays) { item in
                        Text(item.name).tag(item.id as UUID?)
                    }
                }
            }
            
            if baseVariable.type == .integer && variableBinding.wrappedValue == nil {
                // Custom Range
                let lowerboundBinding = settings.intValue(value.second).unwrap(default: 0)
                let upperboundBinding = settings.intValue(value.third).unwrap(default: 0)
                HStack {
                    TextField("Lowerbound", value: lowerboundBinding, formatter: NumberFormatter())
                    Text("-")
                    TextField("Upperbound", value: upperboundBinding, formatter: NumberFormatter())
                }
            }
        } else {
            Text("This variable does not support iterating!")
        }
    }
}

extension FlowchartItem {
    /// Helper function to get a displayable version of iteration settings
    func iterationDisplayText(key: IterationPicker.ValueKey, flowchart: Flowchart) -> String {
        let variableKey = key.first
        if storage[variableKey] == nil {
            // Custom value
            let lowerbound = storage[key.second] ?? 0
            let upperbound = storage[key.third] ?? 0
            return "\(lowerbound) - \(upperbound)"
        } else {
            let variableName = variableDisplayText(key: variableKey, flowchart: flowchart)
            if variableName.isSuccessful {
                return "in " + variableName.text
            } else {
                return "Error"
            }
        }
    }
}

// MARK: - Index Picker
typealias IndexPicker = IndexPickerSettingItem
struct IndexPickerSettingItem: SettingItem {
    var title: String
    
    /// The base variable that this picker will be selecting the index for
    var baseVariable: UUIDKey
    
    /// 1. An integer variable that represents the index
    /// 2. Custom value (if needed)
    typealias ValueKey = HybridSettingsKey<UUIDKey, IntKey>
    var value: ValueKey
    
    func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        let variableSelection = settings.uuidValue(value.first)
        Picker(title, selection: variableSelection) {
            Text("Custom").tag(nil as UUID?)
            
            Divider()
            
            // Filter the array to only include integer and exclude base variable
            let iterationArray = flowchart.variables.filter { $0.type == .integer && $0.id != settings.wrappedValue[baseVariable] }
            ForEach(iterationArray) { variable in
                Text(variable.name).tag(variable.id as UUID?)
            }
        }
        
        if variableSelection.wrappedValue == nil {
            // Custom
            let customValue = settings.intValue(value.second).unwrap(default: 0)
            HStack {
                Spacer()
                Stepper("\(customValue.wrappedValue)", value: customValue)
            }
            .onChange(of: customValue.wrappedValue, perform: { value in
                if value < 0 {
                    // Don't go below 0
                    customValue.wrappedValue = 0
                }
            })
        }
    }
}
extension FlowchartItem {
    func indexPickerLabel(baseVariableName: String, index key: IndexPicker.ValueKey, flowchart: Flowchart) -> String {
        if storage[key.first] != nil {
            let indexVariable = variableDisplayText(key: key.first, flowchart: flowchart)
            if indexVariable.isSuccessful {
                return "\(baseVariableName)[\(indexVariable.text)]"
            } else {
                return "\(baseVariableName)[index error]"
            }
        } else {
            let customIndex = storage[key.second] ?? 0
            return "\(baseVariableName)[\(customIndex)]"
        }
    }
}

// MARK: - Set Value Picker
// TODO: Support 2D array
/// Similar to `VariablePicker`, but allows picking of specific value such as an value corresponding to an index of an array
typealias SetValuePicker = SetValuePickerSettingItem
struct SetValuePickerSettingItem: SettingItem {
    var title: String
    
    /// 1. The base variable 2. Whether to use array index 3. The array index variable (if needed) 4. The custom array index
    /// 1 is used in a `VariablePicker`. 3,4 is used in an `IndexPicker`
    typealias ValueKey = HybridSettingsKey4<UUIDKey, IntKey, UUIDKey, IntKey>
    var variable: ValueKey
    
    func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        // Borrow the variable picker
        let variablePicker = VariablePicker(title: title, variable: variable.first)
        let chosenVariable = settings.wrappedValue[variable.first]
        let useIndexBinding = settings.intValue(variable.second)
        
        variablePicker.generateView(for: flowchart, settings: settings)
            .onChange(of: chosenVariable) { newValue in
                // Variable changed, if it's not array, deselect use index
                if let newValue = newValue,
                   let variable = flowchart.getVariable(with: newValue),
                   [.integer, .string].contains(variable.type) {
                    useIndexBinding.wrappedValue = 0
                }
            }
        
        if let baseVariableValue = settings.wrappedValue[variable.first],
           let baseVariable = flowchart.getVariable(with: baseVariableValue),
           [.intArray, .stringArray].contains(baseVariable.type) {
            // Array selected, show an use index binding
            let indexToggleBinding = Binding<Bool> {
                return useIndexBinding.wrappedValue == 1
            } set: { newValue in
                useIndexBinding.wrappedValue = newValue ? 1 : 0
            }
            Toggle("Set element within array", isOn: indexToggleBinding)
            
            if indexToggleBinding.wrappedValue == true {
                // Show an index picker
                let indexPickerKey = IndexPicker.ValueKey(first: variable.third, second: variable.fourth)
                // Base variable is actually not needed
                let indexPicker = IndexPicker(title: "Index", baseVariable: variable.first, value: indexPickerKey)
                indexPicker.generateView(for: flowchart, settings: settings)
            }
        }
    }
    
    static func projectedType(key: ValueKey, settings: SettingValuesStorage, flowchart: Flowchart) -> FlowchartVariable.VariableType? {
        if let baseVariableValue = settings[key.first],
           let baseVariable = flowchart.getVariable(with: baseVariableValue) {
            // Found base variable
            if [.string, .integer].contains(baseVariable.type) {
                // Is integer, return the type
                return baseVariable.type
            } else if [.intArray, .stringArray].contains(baseVariable.type) {
                // Array, check value
                let useIndex = settings[key.second]
                if useIndex == 1 {
                    if case .intArray = baseVariable.type {
                        return .integer
                    } else {
                        // Assume string
                        return .string
                    }
                } else {
                    return baseVariable.type
                }
            } else {
                // Error, return nil
                return nil
            }
        }
        // Base variable doesn't exist
        return nil
    }
    
    static func isAssigningArray(key: ValueKey, storage: SettingValuesStorage) -> Bool {
        return storage[key.second] == 1
    }
}

extension FlowchartItem {
    /// Helper function to get a displayable name of variable from setting storage
    func setValueDisplayText(key: SetValuePicker.ValueKey, flowchart: Flowchart) -> (text: String, isSuccessful: Bool) {
        let variableKey = key.first
        let variableName = variableDisplayText(key: variableKey, flowchart: flowchart)
        if variableName.isSuccessful {
            if storage[key.second] == 1 {
                // Array with index is selected
                let indexKey = IndexPicker.ValueKey(first: key.third, second: key.fourth)
                let indexPickerName = indexPickerLabel(baseVariableName: variableName.text, index: indexKey, flowchart: flowchart)
                return (indexPickerName, true)
            } else {
                return (variableName.text, true)
            }
        } else {
            return ("Select Variable", false)
        }
    }
}
