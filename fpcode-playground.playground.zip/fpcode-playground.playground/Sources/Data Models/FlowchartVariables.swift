//
//  FlowchartVariables.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/14.
//

// Flowchart variables are stored separately rather than values in the variable block
// because this makes modifying and accessing them in other blocks easier.

import Foundation

// MARK: - Flowchart Variable
/// Make all possible data type for variables conforms to this protocol to allow easy handling of data
protocol FlowchartVariableDataType: Codable {}
extension Int: FlowchartVariableDataType {}
extension String: FlowchartVariableDataType {}
extension Array: FlowchartVariableDataType where Element: FlowchartVariableDataType {}

struct FlowchartVariable: Codable, Identifiable, Hashable {
    /// Stores the type of variable used
    enum VariableType: Int, Codable, CaseIterable {
        case integer = 0
        case string = 1
        case intArray = 2
        case stringArray = 3
//        case twoDimensionalIntArray = 4
        
        /// Initialize based on the variable passed to `value`
        init(from value: FlowchartVariableDataType) {
            switch value {
            case is Int: self = .integer
            case is String: self = .string
            case is [Int]: self = .intArray
//            case is [[Int]]: self = .twoDimensionalIntArray
            default: self = .stringArray
            }
        }
        /// Display name for each data type
        func displayName() -> String {
            switch self {
            case .integer: return "Int"
            case .string: return "String"
            case .intArray: return "Int Array"
            case .stringArray: return "String Array"
//            case .twoDimensionalIntArray: return "2D Int Array"
            }
        }
    }

    /// An `UUID` for this variable
    var id: UUID
    /// The name of this variable
    var name: String
    /// The value type of this variable
    private var _type: VariableType
    /// The initial value of this variable
    var initialData: Data
    
    /// Custom coding keys with alias for `_type`
    private enum CodingKeys: String, CodingKey {
        case id, name, initialData
        case _type = "type"
    }
    
    var type: VariableType {
        get { return _type }
        set {
            convertValue(to: newValue)
            _type = newValue
        }
    }
    
    init<ValueType: FlowchartVariableDataType>(name: String, initialData: ValueType) {
        self.id = UUID()
        self.name = name
        self._type = VariableType(from: initialData)
        self.initialData = Self.encodeData(initialData)
    }
    
    static func encodeData<ValueType: FlowchartVariableDataType>(_ value: ValueType) -> Data {
        return try! JSONEncoder().encode(value)
    }
    
    /// Get the initial value as int.
    /// Note: Make sure `type` is `.integer` before calling this function
    func getIntegerValue() -> Int {
        return (try? JSONDecoder().decode(Int.self, from: initialData)) ?? 0
    }
    
    /// Get the initial value as string.
    /// Note: Make sure `type` is `.string` before calling this function
    func getStringValue() -> String {
        return (try? JSONDecoder().decode(String.self, from: initialData)) ?? ""
    }
    
    /// Get the initial value as int.
    /// Note: Make sure `type` is a kind of array before calling this function
    func getArrayValue<T: FlowchartVariableDataType>(of type: T.Type = T.self) -> [T] {
        return (try? JSONDecoder().decode([T].self, from: initialData)) ?? []
    }
    
    /// Get a displayable text representation for the initial value of this variable
    func displayValue() -> String {
        switch type {
        case .integer:
            let intValue = getIntegerValue()
            return String(intValue)
        case .string:
            return getStringValue()
        default:
            // Just display the json of the data
            return String(decoding: initialData, as: UTF8.self)
        }
    }
    
    /// Get a preview for the variable in the following format:
    /// `name = value`
    func makePreview() -> String {
        return "\(name) = \(displayValue())"
    }
    
    /// When the type change, call this method to convert the data to the new format
    /// before updating the view to avoid error.
    private mutating func convertValue(to newType: VariableType) {
        // TODO: Convert value
        // For now just reset the value to the default state
        switch newType {
        case .integer: initialData = Self.encodeData(0)
        case .string: initialData = Self.encodeData("")
        case .intArray: initialData = Self.encodeData([Int]())
        case .stringArray: initialData = Self.encodeData([String]())
//        case .twoDimensionalIntArray: initialData = Self.encodeData([[Int]]())
        }
    }
    
    var isArray: Bool {
        return [VariableType.intArray, .stringArray].contains(type)
    }
}

