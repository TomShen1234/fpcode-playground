//
//  FlowchartItemSettings.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/14.
//

// This file stores the structure for the settings of each flowchart item

import SwiftUI
import Foundation

/// Base for setting items
protocol SettingItem: SettingGenerating {
    associatedtype ViewType: View
    /// Generate a SwiftUI view for this setting
    /// - Parameters:
    ///   - flowchart: The flowchart to edit
    ///   - item: The item in the flowchart to edit
    @ViewBuilder func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> ViewType
}

extension SettingItem {
    func generateViewAsAnyView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> AnyView {
        return generateView(for: flowchart, settings: settings).eraseToAnyView()
    }
    
    var generators: [SettingGenerator] {
        return [SettingGenerator(makeView: generateViewAsAnyView)]
    }
}

// MARK: - Setting items implementation
// Moved to SettingItems.swift

// MARK: - Settings Builder
/// Used to aggregate all the `SettingItem`s into a combined `FlowchartItemSettings`
/// which can be displayed to the user.
@_functionBuilder struct FlowchartSettingsBuilder {
    static func buildBlock() -> [SettingGenerator] {
        // Empty block
        return []
    }
    
    static func buildBlock(_ generators: SettingGenerating...) -> [SettingGenerator] {
        return generators.flatMap(\.generators)
    }
    
    static func buildOptional(_ generators: [SettingGenerating]?) -> [SettingGenerator] {
        return generators?.flatMap(\.generators) ?? []
    }
    
    static func buildFinalResult(_ components: [SettingGenerator]) -> FlowchartItemSettings {
        return FlowchartItemSettings(generators: components)
    }
}

// MARK: - Aggregated Settings
/// A protocol that allows `SettingGenerator` to be created
protocol SettingGenerating {
    var generators: [SettingGenerator] { get }
}

/// Create `SettingGenerator` to erase type information about the setting item itself
struct SettingGenerator: SettingGenerating {
    var generators: [SettingGenerator] { [self] }
    /// The block to run to create the view
    var makeView: (Flowchart, Binding<SettingValuesStorage>) -> AnyView
}

// Allow arrays with SettingGenerators to conform to SettingGenerating protocol
extension Array: SettingGenerating where Element == SettingGenerator {
    var generators: [SettingGenerator] {
        return self
    }
}

struct FlowchartItemSettings {
    var generators: [SettingGenerator]
    
    /// Create a view that can be displayed in the settings view
    @ViewBuilder func generateView(for flowchart: Flowchart, settings: Binding<SettingValuesStorage>) -> some View {
        if generators.isEmpty {
            VStack {
                Spacer()
                Text("No values to inspect.")
                Spacer()
            }
        } else {
            ForEach(generators.indices, id: \.self) { index in
                Text("")
                // Get each block and make the view
                let settingGenerator = generators[index]
                settingGenerator.makeView(flowchart, settings)
            }
        }
    }
}

// MARK: - Setting Value Storage
struct SettingValuesStorage: Codable {
    var integers = [String: Int]()
    var strings = [String: String]()
    var uuids = [String: UUID]()
    
    subscript<Key>(_ key: Key) -> Key.Value? where Key: SettingStorageKey {
        get {
            return get(key)
        }
        set {
            set(value: newValue, to: key)
        }
    }
    
    func get<Key>(_ key: Key) -> Key.Value? where Key: SettingStorageKey {
        switch key {
        case is IntKey:
            return integers[key.value] as? Key.Value
        case is StringKey:
            return strings[key.value] as? Key.Value
        case is UUIDKey:
            return uuids[key.value] as? Key.Value
        default:
            return nil
        }
    }
    
    mutating func set<Key>(value: Key.Value?, to key: Key) where Key: SettingStorageKey {
        switch key {
        case is IntKey:
            integers[key.value] = value as? Int
        case is StringKey:
            strings[key.value] = value as? String
        case is UUIDKey:
            uuids[key.value] = value as? UUID
        default:
            break
        }
    }
}

protocol SettingStorageKey: ExpressibleByStringLiteral {
    associatedtype Value: Codable
    /// Key to search for this value in the dictionary
    var value: String { get set }
    init(value: String)
}

extension SettingStorageKey {
    init(stringLiteral value: String) {
        self.init(value: value)
    }
}

struct IntKey: SettingStorageKey {
    typealias Value = Int
    var value: String
}

struct StringKey: SettingStorageKey {
    typealias Value = String
    var value: String
}

struct UUIDKey: SettingStorageKey {
    typealias Value = UUID
    var value: String
}

// MARK: - Hybrid Settings Key

/// A convenient way to create 2 setting keys, they act as 1 key and shares the same key value
struct HybridSettingsKey<First: SettingStorageKey, Second: SettingStorageKey>: ExpressibleByStringLiteral {
    // When creating the actual key, add a trailing index to allow multiple key of the same name
    var first: First
    var second: Second
    
    init(value: String) {
        self.first = First(value: value + "1")
        self.second = Second(value: value + "2")
    }
    
    init(first: First, second: Second) {
        self.first = first
        self.second = second
    }
    
    init(stringLiteral value: String) {
        self.init(value: value)
    }
}

struct HybridSettingsKey3<First: SettingStorageKey, Second: SettingStorageKey, Third: SettingStorageKey>: ExpressibleByStringLiteral {
    // When creating the actual key, add a trailing index to allow multiple key of the same name
    var first: First
    var second: Second
    var third: Third
    
    init(value: String) {
        self.first = First(value: value + "1")
        self.second = Second(value: value + "2")
        self.third = Third(value: value + "3")
    }
    
    init(first: First, second: Second, third: Third) {
        self.first = first
        self.second = second
        self.third = third
    }
    
    init(stringLiteral value: String) {
        self.init(value: value)
    }
}

struct HybridSettingsKey4<First: SettingStorageKey, Second: SettingStorageKey, Third: SettingStorageKey, Fourth: SettingStorageKey>: ExpressibleByStringLiteral {
    // When creating the actual key, add a trailing index to allow multiple key of the same name
    var first: First
    var second: Second
    var third: Third
    var fourth: Fourth
    
    init(value: String) {
        self.first = First(value: value + "1")
        self.second = Second(value: value + "2")
        self.third = Third(value: value + "3")
        self.fourth = Fourth(value: value + "4")
    }
    
    init(first: First, second: Second, third: Third, fourth: Fourth) {
        self.first = first
        self.second = second
        self.third = third
        self.fourth = fourth
    }
    
    init(stringLiteral value: String) {
        self.init(value: value)
    }
}

struct HybridSettingsKey5<First: SettingStorageKey, Second: SettingStorageKey, Third: SettingStorageKey, Fourth: SettingStorageKey, Fifth: SettingStorageKey>: ExpressibleByStringLiteral {
    // When creating the actual key, add a trailing index to allow multiple key of the same name
    var first: First
    var second: Second
    var third: Third
    var fourth: Fourth
    var fifth: Fifth
    
    init(value: String) {
        self.first = First(value: value + "1")
        self.second = Second(value: value + "2")
        self.third = Third(value: value + "3")
        self.fourth = Fourth(value: value + "4")
        self.fifth = Fifth(value: value + "5")
    }
    
    init(first: First, second: Second, third: Third, fourth: Fourth, fifth: Fifth) {
        self.first = first
        self.second = second
        self.third = third
        self.fourth = fourth
        self.fifth = fifth
    }
    
    init(stringLiteral value: String) {
        self.init(value: value)
    }
}

// MARK: - Setting Storage + Binding
extension Binding where Value == SettingValuesStorage {
    func intValue(_ key: IntKey) -> Binding<Int?> {
        return self.integers[key.value]
    }
    
    func stringValue(_ key: StringKey) -> Binding<String?> {
        return self.strings[key.value]
    }
    
    func uuidValue(_ key: UUIDKey) -> Binding<UUID?> {
        return self.uuids[key.value]
    }
}
