//
//  FlowchartItems.swift
//  fpcode
//
//  Created by Tom Shen on 2021/1/30.
//

// This file defines the data structure for all the flowcharts items

import Foundation
import SwiftUI

// MARK: - Flowchart Items
// Thanks: https://stackoverflow.com/questions/59364986/swift-decode-encode-an-array-of-generics-with-different-types Codey
/// Base for each flowchart item
protocol FlowchartItem: Codable {
    var id: UUID { get set }
    /// Type of item
    var type: FlowchartItemType { get }
    /// Shape of the item
    var shape: FlowchartShape { get }
    /// Name of the item
    var name: String { get }
    
    /// Child items for this item
    var children: [FlowchartItemContainer] { get set }
    
    /// Storage space for all necessary values for an item
    var storage: SettingValuesStorage { get set }
    
    /// An overview text that displays on top of the inspector view
    var inspectorPreview: String { get }
    
    /// The renderer of this item, which can render it into a view
    var renderer: FlowchartItemRenderer { get }
    
    /// The setting configuration used to generate the inspector view.
    /// It uses the `FlowchartSettingsBuilder` to simplify creation process.
    @FlowchartSettingsBuilder var settings: FlowchartItemSettings { get }
    
    /// Generate the content that goes into the flowchart item's block
    func generateItemContent(for flowchart: Flowchart) -> String?
    
    /// Generate an instance of the item with default values
    static func createDefaultItem() -> Self
    
    /// Validate for missing parameters to determine whether the item can be executed
    func validateForExecution() throws
    
    /// A property that determines whether this item uses the `children` array
    var usesChildren: Bool { get }
    
    /// Execute the item using the provided runtime and call the completion when finished
    func execute(with runtime: FlowchartRuntime, completion: @escaping FlowchartRuntime.ExecuteCompletion, onInput: @escaping FlowchartRuntime.InputHandler)
}

extension FlowchartItem {
    // Default implementation for settings
    var settings: FlowchartItemSettings {
        FlowchartItemSettings(generators: [])
    }
    
    // Default Implementation that returns the name
    var inspectorPreview: String {
        return name
    }
    
    // Default implementation for renderer that returns a single item renderer with self
    var renderer: FlowchartItemRenderer {
        return FlowchartItemRenderer(singleItem: self)
    }
    
    /// Convenient shorthand to access the children as `FlowchartItem`
    var childItems: [FlowchartItem] {
        return children.map(\.item)
    }
    
    /// Creates a `FlowchartTreeItem` for this object
    var treeItem: FlowchartTreeItem {
        FlowchartTreeItem(item: self)
    }
    
    /// Get whether this item is generated
    var isGenerated: Bool {
        return generatedItemTypes.contains { itemType in
            return itemType == Self.self
        }
    }
    
    // Default implementation of `usesChildren` that returns false
    var usesChildren: Bool { return false }
    
    // MARK: Validation
    
    // Default implementation of validation to perform no-op, therefore successful
    func validateForExecution() {}
    
    /// Perform validation of item according to the provided closure, allowing recursive validation on children as well
    func performValidation() -> (result: Result<Void, Error>, failureItem: FlowchartItem?) {
        var failureItem: FlowchartItem? = nil
        
        let result = Result {
            try validateForExecution()
        }
        .mapError { error -> Error in
            // Set the failure item to self if self validation failed
            failureItem = self
            return error
        }
        .flatMap { _ -> Result<Void, Error> in
            if usesChildren {
                let childrenValidation = validateChildren()
                if case .failure = childrenValidation.result {
                    // Child validation failed, set failed item
                    failureItem = childrenValidation.failureItem
                }
                return childrenValidation.result
            } else {
                // Just pass it on
                return .success(())
            }
        }
        
        return (result, failureItem)
    }
    
    /// Validates all children and returns the result
    private func validateChildren() -> (result: Result<Void, Error>, failureItem: FlowchartItem?) {
        var failureItem: FlowchartItem? = nil
        let result = Result {
            // Iterate through children
            try children.forEach { childContainer in
                do {
                    // Validate child and allow it to throw
                    try childContainer.item.validateForExecution()
                } catch {
                    // Catch the error, set the failure item, and rethrow the error
                    failureItem = childContainer.item
                    throw error
                }
            }
        }
        return (result, failureItem)
    }
    
    // MARK: Execution
    
    // Default implementation of execute, performing no-op
    func execute(with runtime: FlowchartRuntime, completion: FlowchartRuntime.ExecuteCompletion, onInput: FlowchartRuntime.InputHandler) {
        completion(.success(()), nil)
    }
    
    // MARK: Manipulative Functions
    
    /// Convenient function to add a children
    mutating func add(child: FlowchartItem, branch: FlowchartItemContainer.Branch? = nil) {
        // Check if there is a placeholder
        var childContainer = FlowchartItemContainer(item: child)
        childContainer.branch = branch
        add(child: childContainer)
    }
    
    /// Convenient function to add a children container
    private mutating func add(child: FlowchartItemContainer, to index: Int? = nil) {
        var placeholderRemoved = false
        if child.branch == nil {
            if children.count == 1, children.first!.item is PlaceholderItem {
                // Placeholder item found when branching is disabled, remove it first
                children.removeAll()
                placeholderRemoved = true
            }
        } else {
            let filteredBranch = children.filter { $0.branch == child.branch }
            if filteredBranch.count == 1, filteredBranch.first!.item is PlaceholderItem {
                // Placeholder item found in branch, remove it
                children.removeAll(where: { $0.item.id == filteredBranch.first!.item.id})
                placeholderRemoved = true
            }
        }
        
        if let index = index {
            let placeholderOffset = placeholderRemoved ? 1 : 0
            children.insert(child, at: index - placeholderOffset)
        } else {
            children.append(child)
        }
    }
    
    // TODO: Optimize the code?
    
    /// Find and add item to `children` recursively if possible
    /// - Returns: `true` if successful, `false` if not.
    @discardableResult
    mutating func findAndAdd(item: FlowchartItemContainer, after selectedItem: FlowchartItem) -> Bool {
        var itemToAdd = item
        // Find within children first
        if let index = childItems.firstIndex(where: { $0.id == selectedItem.id }) {
            // Item is a child of this item, add it to the correct branch
            let child = children[index]
            itemToAdd.branch = child.branch
            add(child: itemToAdd, to: index + 1)
            return true
        } else {
            // Item is not found, try repeating recursively
            for index in childItems.indices {
                if children[index].item.findAndAdd(item: item, after: selectedItem) {
                    // Found and added in children, return true
                    return true
                }
            }
        }
        return false
    }
    
    /// Find and delete item to `children` recursively if possible
    /// - Returns: `true` if successful, `false` if not.
    @discardableResult
    mutating func findAndDelete(target: UUID) -> Bool {
        if let index = childItems.firstIndex(where: { $0.id == target }) {
            let removed = children.remove(at: index)
            if removed.branch == nil, children.count == 0 {
                // No branching, array is empty, insert placeholder
                add(child: PlaceholderItem())
            } else {
                let removedBranch = children.filter { $0.branch == removed.branch }
                if removedBranch.count == 0 {
                    // No more item in branch, insert placeholder in the branch
                    add(child: PlaceholderItem(), branch: removed.branch)
                }
            }
            return true
        } else {
            // Item is not found, try repeating recursively
            for index in childItems.indices {
                if children[index].item.findAndDelete(target: target) {
                    // Found and added in children, return true
                    return true
                }
            }
        }
        return false
    }
    
    /// Find and update item to `children` recursively if possible
    /// - Returns: `true` if successful, `false` if not.
    @discardableResult
    mutating func findAndUpdate(item: FlowchartItem) -> Bool {
        if let index = childItems.firstIndex(where: { $0.id == item.id }) {
            let branch = children[index].branch
            children[index] = FlowchartItemContainer(item: item, branch: branch)
            return true
        } else {
            // Item is not found, try repeating recursively
            for index in childItems.indices {
                if children[index].item.findAndUpdate(item: item) {
                    // Found and added in children, return true
                    return true
                }
            }
        }
        return false
    }
    
    func find(target: UUID) -> FlowchartItem? {
        if let child = childItems.first(where: { $0.id == target }) {
            return child
        } else {
            for child in childItems {
                if let foundItem = child.find(target: target) {
                    return foundItem
                }
            }
        }
        return nil
    }
    
    mutating func moveUp(target: UUID) -> Bool {
        if let itemIndex = children.firstIndex(where: { $0.item.id == target }) {
            guard itemIndex != children.endIndex else { return true } // Cannot move
            children.rearrange(from: itemIndex, to: itemIndex - 1)
        } else {
            for index in children.indices {
                if children[index].item.moveUp(target: target) {
                    return true
                }
            }
        }
        return false
    }
    
    mutating func moveDown(target: UUID) -> Bool {
        if let itemIndex = children.firstIndex(where: { $0.item.id == target }) {
            guard itemIndex != children.endIndex else { return true } // Cannot move
            children.rearrange(from: itemIndex, to: itemIndex + 1)
        } else {
            for index in children.indices {
                if children[index].item.moveDown(target: target) {
                    return true
                }
            }
        }
        return false
    }
}

// MARK: - Item Storage

enum FlowchartItemType: Int, Codable, CaseIterable {
    // The raw value of this enum does not have a meaning
    // They're indexed from oldest added to newest
    case ifElse = 0
    case `if` = 10
    case setVariable = 1
    case whileLoop = 2
    case forLoop = 3
    case input = 4
    case output = 5
    case operation = 9
    
    // Generated Items
    case startEnd = 6
    case variable = 7
    case placeholder = 8
    
    func getType() -> FlowchartItem.Type {
        switch self {
        case .startEnd: return StartEndItem.self
        case .variable: return VariableItem.self
        case .placeholder: return PlaceholderItem.self
        case .ifElse: return IfElseItem.self
        case .if: return IfItem.self
        case .setVariable: return SetVariableItem.self
        case .whileLoop: return WhileLoopItem.self
        case .forLoop: return ForLoopItem.self
        case .input: return InputItem.self
        case .output: return OutputItem.self
        case .operation: return OperationItem.self
        }
    }
}

enum FlowchartShape: CaseIterable {
    case rectangle
    case parallelogram
    case capsule
    case diamond
    case dottedRectangle
}

struct FlowchartItemContainer: Codable {
    /// Store branching info of children for a flowchart item
    enum Branch: Int {
        case a = 1
        case b = 2
    }
    
    var itemType: FlowchartItemType { item.type }
    var item: FlowchartItem
    
    var branch: Branch?
    
    enum CodingKeys: CodingKey {
        case item, itemType, branch
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(itemType, forKey: .itemType)
        let fromContainer = container.superEncoder(forKey: .item)
        try item.encode(to: fromContainer)
        
        if let branchData = branch {
            try container.encode(branchData.rawValue, forKey: .branch)
        }
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        let type = try container.decode(FlowchartItemType.self, forKey: .itemType)
        let fromDecoder = try container.superDecoder(forKey: .item)
        self.item = try type.getType().init(from: fromDecoder)
        
        if container.contains(.branch) {
            let branchValue = try container.decode(Int.self, forKey: .branch)
            branch = Branch(rawValue: branchValue)
        } else {
            branch = nil
        }
    }
    
    init(item: FlowchartItem, branch: Branch? = nil) {
        self.item = item
        self.branch = branch
    }
}

// MARK: - Flowchart Tree Item
struct FlowchartTreeItem: Identifiable, Hashable {
    var id: UUID
    var item: FlowchartItem
    var children: [FlowchartTreeItem]?
    
    init(item: FlowchartItem) {
        // TODO: Support Branching
        self.id = item.id
        self.item = item
        if item.children.isEmpty {
            self.children = nil
        } else {
            // Create tree item recursively for children
            self.children = item.children.map(\.item.treeItem)
        }
    }
    
    // MARK: Hashable
    static func == (lhs: FlowchartTreeItem, rhs: FlowchartTreeItem) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    /// Find the corresponding `FlowchartItem` within this tree item
    /// - Parameter id: The input ID
    /// - Returns: The item if found, `nil` if not.
    func findItem(id: UUID) -> FlowchartItem? {
        if self.id == id {
            // self is the item, return it
            return self.item
        } else if let children = self.children {
            // Find recursively
            for child in children {
                if let item = child.findItem(id: id) {
                    return item
                }
            }
            return nil
        } else {
            // No children, return nil
            return nil
        }
    }
}

// MARK: - Default Items

/// An arrays of items that can be added by the user
var flowchartLibraryItems: [FlowchartItem] = { () -> [FlowchartItem] in
    let supportedItemTypes: [FlowchartItem.Type] = [SetVariableItem.self, OperationItem.self, IfItem.self, IfElseItem.self, WhileLoopItem.self, ForLoopItem.self, InputItem.self, OutputItem.self]
    
    return supportedItemTypes.map { $0.createDefaultItem() }
}()

var generatedItemTypes: [FlowchartItem.Type] = [StartEndItem.self, VariableItem.self]
