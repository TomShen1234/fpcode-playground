//
//  SwiftUIHelpers.swift
//  fpcode
//
//  Created by Tom Shen on 2021/1/30.
//

import SwiftUI

// MARK: - Navigation Bar Title Display Mode Compatibility
extension View {
    /// Configures the title display mode for this view only on iOS.
    /// - Parameter displayMode: The style to use for displaying the title.
    @ViewBuilder func navigationBarTitleDisplayModeIfAvailable(_ displayMode: NavigationBarItem.TitleDisplayMode) -> some View {
        #if os(iOS)
        self.navigationBarTitleDisplayMode(displayMode)
        #elseif os(macOS)
        self
        #endif
    }
}
#if os(macOS)
enum NavigationBarItem {
    enum TitleDisplayMode {
        case automatic, inline, large
    }
}
#endif

// MARK: - Text Field Auto Capitalization Compatibility
extension View {
    /// Sets whether to apply auto-capitalization to this view, only on iOS
    /// - Parameter style: One of the autocapitalization modes defined in the `UITextAutocapitalizationType` enumeration.
    @ViewBuilder func autocapitalizationIfAvailable(_ style: AutocapitalizationType) -> some View {
        #if os(iOS)
        self.autocapitalization(style.uiKitAutocapitalizationType())
        #elseif os(macOS)
        self
        #endif
    }
}

enum AutocapitalizationType : Int {
    case none = 0
    case words = 1
    case sentences = 2
    case allCharacters = 3
    
    #if os(iOS)
    func uiKitAutocapitalizationType() -> UITextAutocapitalizationType {
        return UITextAutocapitalizationType(rawValue: rawValue)!
    }
    #endif
}

// MARK: - Text Field Keyboard Type Compatibility
extension View {
    /// Sets the keyboard type for this view.
    /// - Parameter type: One of the keyboard types defined in the `UIKeyboardType` enumeration.
    @ViewBuilder func keyboardTypeIfAvailable(_ type: KeyboardType) -> some View {
        #if os(iOS)
        self.keyboardType(type.uiKeyboardType())
        #elseif os(macOS)
        self
        #endif
    }
}

enum KeyboardType : Int {
    case `default` = 0 // Default type for the current input method.
    case asciiCapable = 1 // Displays a keyboard which can enter ASCII characters
    case numbersAndPunctuation = 2 // Numbers and assorted punctuation.
    case URL = 3 // A type optimized for URL entry (shows . / .com prominently).
    case numberPad = 4 // A number pad with locale-appropriate digits (0-9, ۰-۹, ०-९, etc.). Suitable for PIN entry.
    case phonePad = 5 // A phone pad (1-9, *, 0, #, with letters under the numbers)
    case namePhonePad = 6 // A type optimized for entering a person's name or phone number.
    case emailAddress = 7 // A type optimized for multiple email address entry (shows space @ . prominently).
    case decimalPad = 8 // A number pad with a decimal point.
    case twitter = 9 // A type optimized for twitter text entry (easy access to @ #)
    case webSearch = 10 // A default keyboard type with URL-oriented addition (shows space . prominently).
    case asciiCapableNumberPad = 11 // A number pad (0-9) that will always be ASCII digits.
    
    #if os(iOS)
    func uiKeyboardType() -> UIKeyboardType {
        return UIKeyboardType(rawValue: rawValue)!
    }
    #endif
}

// MARK: - Custom Shapes
struct Parallelogram: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.width / 8, y: 0))
        path.addLine(to: CGPoint(x: rect.width, y: 0))
        path.addLine(to: CGPoint(x: (rect.width / 8) * 7, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: rect.height))
        path.closeSubpath()
        return path
    }
}

struct Diamond: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.width / 2, y: 0))
        path.addLine(to: CGPoint(x: rect.width, y: rect.height / 2))
        path.addLine(to: CGPoint(x: rect.width / 2, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: rect.height / 2))
        path.closeSubpath()
        return path
    }
}

// MARK: - List Border Overlay for macOS
#if os(macOS)
/// Create a border for `List` views
struct ListBorderOverlay: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 15)
            .stroke(Color(.separatorColor))
    }
}
#endif

// MARK: - Is Hidden
extension View {
    /// Set the `hidden` modifier on the view according to a boolean value
    @ViewBuilder func isHidden(_ flag: Bool) -> some View {
        if flag {
            self.hidden()
        } else {
            self
        }
    }
}

// MARK: - AnyView eraser
extension View {
    /// Erase the type of this view to `AnyView`
    func eraseToAnyView() -> AnyView {
        return AnyView(self)
    }
}

// MARK: - Unwrap Binding
extension Binding {
    /// Create a binding by performing nil-coalescing on optional values
    func unwrap<V>(default value: @autoclosure @escaping () -> V) -> Binding<V> where Value == V? {
        Binding<V> {
            wrappedValue ?? value()
        } set: { newValue in
            wrappedValue = newValue
        }
    }
}

// MARK: - Binding onChange
// https://www.hackingwithswift.com/quick-start/swiftui/how-to-run-some-code-when-state-changes-using-onchange
extension Binding {
    /// Call a handler before the binding's value change
    func onChange(_ handler: @escaping (Value) -> ()) -> Binding<Value> {
        Binding(
            get: { self.wrappedValue },
            set: { newValue in
                handler(newValue)
                self.wrappedValue = newValue
            }
        )
    }
    
    /// Call a handler after the binding's value change
    func didChange(_ handler: @escaping () -> ()) -> Binding<Value> {
        Binding(
            get: { self.wrappedValue },
            set: { newValue in
                self.wrappedValue = newValue
                // Since block is called after setting value, we will not pass it back
                handler()
            }
        )
    }
}

// MARK: - iOS Compact Sheet
@available(iOS 14, *)
@available(macOS, unavailable)
struct CompactSheet<SheetContent: View>: ViewModifier {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    
    @Binding var isPresented: Bool
    var makeContent: () -> SheetContent // TODO: Use new syntax from Swift 5.4

    init(isPresented: Binding<Bool>, content: @escaping () -> SheetContent) {
        self._isPresented = isPresented
        self.makeContent = content
    }
    
    @ViewBuilder func body(content: Content) -> some View {
        if horizontalSizeClass == .compact {
            content.sheet(isPresented: $isPresented, content: makeContent)
        } else {
            content
        }
    }
}
@available(iOS 14, *)
@available(macOS, unavailable)
extension View {
    /// Presents a sheet when a given condition is true, and only on compact horizontal sizes (for example, iPhone).
    /// - Parameters:
    ///   - isPresented: A binding to whether the sheet is presented.
    ///   - content: A closure returning the content of the sheet.
    func compactSheet<C:View>(isPresented: Binding<Bool>, @ViewBuilder content: @escaping () -> C) -> some View {
        modifier(CompactSheet(isPresented: isPresented, content: content))
    }
}

// MARK: - Debug print initializer view
struct PrintDebugView: View {
    init(text: String) {
        print(text)
    }
    
    var body: some View {
        EmptyView()
    }
}

// MARK: - Conditional Operators
extension View {
    @ViewBuilder func modify<New:View>(if condition: Bool, modification: (Self) -> New) -> some View {
        if condition {
            modification(self)
        } else {
            self
        }
    }
}

// MARK: - Size Reader
// Slightly modified from:
// https://stackoverflow.com/questions/56573373/swiftui-get-size-of-child tadija
protocol SizeReaderKey: PreferenceKey where Value == CGSize {}

extension SizeReaderKey {
    static func reduce(value _: inout CGSize, nextValue: () -> CGSize) {
        _ = nextValue()
    }
}

struct SizeReader<Key: SizeReaderKey>: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(
                GeometryReader { geo in
                    Color.clear
                        .onAppear()
                        .preference(key: Key.self, value: geo.size)
                }
            )
    }
}

extension View {
    /// Attaches a size reader and subscribes for changes
    func onSizeChanged<Key: SizeReaderKey>(
        _ key: Key.Type,
        perform action: @escaping (CGSize) -> Void) -> some View
    {
        self.modifier(SizeReader<Key>())
            .onPreferenceChange(key) { value in
                action(value)
            }
    }
}

// MARK: - Delay
/// Delay execution of a block for a specified amount of time
func delay(seconds: Double, queue: DispatchQueue = .main, block: @escaping () -> ()) {
    queue.asyncAfter(deadline: .now() + seconds, execute: block)
}
