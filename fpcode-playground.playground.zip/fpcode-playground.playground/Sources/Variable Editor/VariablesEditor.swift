//
//  VariablesEditor.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/3.
//

import SwiftUI

struct VariablesEditor: View {
    @Environment(\.presentationMode) private var presentationMode
    
    @Binding var flowchartVariables: [FlowchartVariable]
    
    @State private var editVariable: FlowchartVariable? = nil
    @State private var showAddVariables = false
    
    @ViewBuilder var body: some View {
        Group {
            #if os(iOS)
            mobileContentWrapper
            #elseif os(macOS)
            macContentWrapper
            #endif
        }
        .sheet(isPresented: $showAddVariables, content: {
            AddVariableView(variables: $flowchartVariables, editing: editVariable)
        })
    }
    #if os(iOS)
    private var mobileContentWrapper: some View {
        NavigationView {
            List {
                editorContent
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Variables")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarLeading) {
                    Button("Close", action: dismiss)
                }
                
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    EditButton()
                    Button(action: addVariable, label: {
                        Image(systemName: "plus")
                    })
                }
            }
        }
    }
    #elseif os(macOS)
    private var macContentWrapper: some View {
        VStack {
            List {
                editorContent
            }
            .overlay(ListBorderOverlay())
            
            HStack {
                Text("*Click row to edit")
                    .foregroundColor(.gray)
                    .font(.footnote)
                
                Button("Close", action: dismiss)
                Button("Add Variable", action: addVariable)
                
                Text("*Click row to edit")
                    .font(.footnote)
                    .hidden() // Padding
            }
        }
        .frame(minWidth: 375, maxWidth: 600, minHeight: 300, maxHeight: 500)
        .padding()
    }
    #endif
    
    @ViewBuilder private var editorContent: some View {
        if !flowchartVariables.isEmpty {
            ForEach(flowchartVariables) { variable in
                // Clicking on each row will edit the row
                Button {
                    editVariable = variable
                    showAddVariables = true
                } label: {
                    HStack {
                        Text(variable.name)
                        Spacer()
                        Text(variable.displayValue())
                    }
                    .background(Color.white.opacity(0.001))
                }
                .buttonStyle(PlainButtonStyle())
            }
            .onDelete(perform: deleteVariable)
        } else {
            noVariableRow
        }
    }
    
    private var noVariableRow: some View {
        HStack {
            Spacer()
            Text("No Variables")
            Spacer()
        }
    }
    
    private func deleteVariable(at offsets: IndexSet) {
        flowchartVariables.remove(atOffsets: offsets)
    }
    
    private func addVariable() {
        editVariable = nil
        showAddVariables = true
    }
    
    private func dismiss() {
        presentationMode.wrappedValue.dismiss()
    }
}
