//
//  AddVariableView.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/3.
//

import SwiftUI
import Combine

struct AddVariableView: View {
    @Environment(\.presentationMode) private var presentationMode
    
    private var editingExisting: Bool
    
    @Binding private var variables: [FlowchartVariable]
    
    @State private var variableToEdit: FlowchartVariable
    
    /// Used to pass message to the editor that the user pressed the save button and that the data needs to be saved
    private let saveSubject = PassthroughSubject<Void, Never>()
    
    @State private var showNameAlreadyExistsError = false
    
    init(variables: Binding<[FlowchartVariable]>, editing: FlowchartVariable? = nil) {
        self._variables = variables
        if let editing = editing {
            self.editingExisting = true
            self._variableToEdit = State(initialValue: editing)
        } else {
            self.editingExisting = false
            self._variableToEdit = State(initialValue: FlowchartVariable(name: "", initialData: 0))
        }
    }
    
    var body: some View {
        Group {
            #if os(iOS)
            mobileContentWrapper
            #elseif os(macOS)
            macContentWrapper
            #endif
        }
        .alert(isPresented: $showNameAlreadyExistsError) {
            Alert(title: Text("Variable Name Overlap"), message: Text("Please use unique variable names."))
        }
    }
    
    #if os(iOS)
    private var mobileContentWrapper: some View {
        NavigationView {
            Form {
                Section {
                    typePicker
                    nameTextField
                }
                
                Section(header: Text("Initial Value"), content: makeEditors)
            }
            .navigationTitle("Add Variable")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarLeading) {
                    Button("Close", action: dismiss)
                }
                
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button("Save", action: save)
                        .disabled(variableToEdit.name.isEmpty)
                }
            }
        }
    }
    #elseif os(macOS)
    private var macContentWrapper: some View {
        VStack {
            typePicker
            nameTextField
            
            makeEditors()
            
            HStack {
                Button("Close", action: dismiss)
                Button("Save", action: save)
                    .disabled(variableToEdit.name.isEmpty)
            }
        }
        .padding()
        .frame(width: 300, height: variableToEdit.isArray ? 250 : 150)
    }
    #endif
    
    private var typePicker: some View {
        Picker("Variable Type", selection: $variableToEdit.type) {
            ForEach(FlowchartVariable.VariableType.allCases, id: \.self) { type in
                let name = type.displayName()
                Text(name).tag(type)
            }
        }
    }
    
    private var nameTextField: some View {
        TextField("Name of Variable", text: $variableToEdit.name)
            .disableAutocorrection(true)
            .autocapitalizationIfAvailable(.none)
    }
    
    @ViewBuilder private func makeEditors() -> some View {
        switch variableToEdit.type {
        case .integer:
            IntegerEditor(value: integerBinding, saveSubject: saveSubject)
        case .string:
            StringEditor(value: stringBinding)
        case .intArray:
            IntegerArrayEditor(values: makeArrayBinding(), saveSubject: saveSubject)
        case .stringArray:
            StringArrayEditor(values: makeArrayBinding())
//        case .twoDimensionalIntArray:
//            Text("TODO: 2D Int Array Editor")
        }
    }
    
    // MARK: - Binding to values
    private var integerBinding: Binding<Int> {
        Binding {
            return variableToEdit.getIntegerValue()
        } set: { newValue in
            variableToEdit.initialData = FlowchartVariable.encodeData(newValue)
        }
    }
    
    private var stringBinding: Binding<String> {
        Binding {
            return variableToEdit.getStringValue()
        } set: { newValue in
            variableToEdit.initialData = FlowchartVariable.encodeData(newValue)
        }
    }
    
    func makeArrayBinding<ValueType: FlowchartVariableDataType>(_ type: ValueType.Type = ValueType.self) -> Binding<[ValueType]> {
        Binding {
            return variableToEdit.getArrayValue()
        } set: { newValue in
            variableToEdit.initialData = FlowchartVariable.encodeData(newValue)
        }
    }
    
    // MARK: - Functions
    private func save() {
        // Update variable data if not already
        saveSubject.send()
        
        // Check whether a different item with the same name already exists
        if !variables.contains(where: { $0.name == variableToEdit.name && $0.id != variableToEdit.id }) {
            if editingExisting {
                // Update existing variable
                if let index = variables.firstIndex(where: {variableToEdit.id == $0.id}) {
                    variables[index] = variableToEdit
                }
            } else {
                // Add new variable
                variables.append(variableToEdit)
            }
            dismiss()
        } else {
            // Name overlap
            showNameAlreadyExistsError = true
        }
    }
    
    private func dismiss() {
        presentationMode.wrappedValue.dismiss()
    }
}

// MARK: - Variable Data Editor

fileprivate struct IntegerEditor: View {
    @Binding var value: Int
    @State private var text = ""
    
    var saveSubject: PassthroughSubject<Void, Never>
    
    var body: some View {
        TextField("Enter Integer Value", text: $text, onCommit: saveValue)
            .keyboardTypeIfAvailable(.numberPad)
            .disableAutocorrection(true)
            .autocapitalizationIfAvailable(.none)
            .onReceive(saveSubject, perform: saveValue)
            .onChange(of: value, perform: updateText)
            .onAppear(perform: {
                updateText(from: value)
            })
    }
    
    private func updateText(from value: Int) {
        text = String(value)
    }
    
    private func saveValue() {
        let intValue: Int
        if let intRep = Int(text) {
            intValue = intRep
        } else {
            // Invalid int value entered into text field
            intValue = 0
            text = String(intValue)
        }
        value = intValue
    }
}

fileprivate struct StringEditor: View {
    @Binding var value: String
    
    var body: some View {
        TextField("Enter string value", text: $value)
            .disableAutocorrection(true)
            .autocapitalizationIfAvailable(.none)
    }
}

fileprivate struct StringArrayEditor: View {
    @Binding var values: [String]
    
    @ViewBuilder var body: some View {
        ScrollView {
            if values.isEmpty {
                Text("Empty Array")
            } else {
                ForEach(values.indices, id: \.self) { index in
                    TextField("Value \(index) Content", text: makeBinding(for: index))
                        .autocapitalizationIfAvailable(.none)
                        .disableAutocorrection(true)
                }
            }
        }
        
        Button(action: addValue, label: {
            Label(title: { Text("Add Value") },
                  icon: { Image(systemName: "plus.circle.fill").renderingMode(.original) })
        })
    }
    
    private func makeBinding(for row: Int) -> Binding<String> {
        Binding {
            return values[row]
        } set: { newValue in
            values[row] = newValue
        }
    }
    
    private func addValue() {
        values.append("")
    }
}

fileprivate struct IntegerArrayEditor: View {
    @Binding var values: [Int]
    @State private var valueTexts = [String]()
    
    var saveSubject: PassthroughSubject<Void, Never>
    
    @ViewBuilder var body: some View {
        ScrollView {
            if values.isEmpty {
                Text("Empty Array")
            } else {
                ForEach(values.indices, id: \.self) { index in
                    TextField("Value \(index) Content", text: makeBinding(for: index), onEditingChanged: { flag in
                        if !flag {
                            // Editing ended
                            saveValue(for: index)
                        }
                    })
                    .autocapitalizationIfAvailable(.none)
                    .disableAutocorrection(true)
                }
                .onReceive(saveSubject, perform: saveAllValues)
                .onChange(of: values, perform: updateValues)
                .onAppear {
                    updateValues(from: values)
                }
            }
        }
        
        Button(action: addValue, label: {
            Label(title: { Text("Add Value") },
                  icon: { Image(systemName: "plus.circle.fill").renderingMode(.original) })
        })
    }
    
    private func updateValues(from values: [Int]) {
        valueTexts = values.map(String.init)
    }
    
    private func makeBinding(for row: Int) -> Binding<String> {
        Binding {
            // Avoid array overflow error when the text is not initialized
            if valueTexts.count > row {
                return valueTexts[row]
            } else {
                return String(values[row])
            }
        } set: { newValue in
            valueTexts[row] = newValue
        }
    }
    
    private func saveAllValues() {
        for i in 0..<valueTexts.count {
            saveValue(for: i)
        }
    }
    
    private func saveValue(for row: Int) {
        let intValue: Int
        if let intRep = Int(valueTexts[row]) {
            intValue = intRep
        } else {
            // Invalid int value entered into text field
            intValue = 0
            valueTexts[row] = String(intValue)
        }
        values[row] = intValue
    }
    
    private func addValue() {
        saveSubject.send() // Save the existing edit
        valueTexts.append("0")
        values.append(0)
    }
}

struct AddVariableView_Previews: PreviewProvider {
    static var previews: some View {
        AddVariableView(variables: .constant([]))
    }
}
