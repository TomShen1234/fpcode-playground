//
//  FlowchartViews.swift
//  fpcode
//
//  Created by Tom Shen on 2021/1/31.
//

import SwiftUI

// MARK: - Flowchart Contents
struct FlowchartContents: View {
    @Binding var flowchart: Flowchart
    
    @Binding var selectedItem: FlowchartItem?
    
    var body: some View {
        // The root view is just a item group view with all the root display items
        LazyVStack(spacing: 2) {
            FlowchartItemGroup(flowchart: flowchart, items: flowchart.displayItems, selectedItem: $selectedItem, itemAction: itemAction)
        }
    }
    
    func itemAction(itemID: UUID, actionType: FlowchartItemView.ActionType) {
        switch actionType {
        case .moveUp:
            flowchart.moveUp(target: itemID)
        case .moveDown:
            flowchart.moveDown(target: itemID)
        case .delete:
            delete(id: itemID)
        }
    }
    
    private func delete(id: UUID) {
        flowchart.delete(item: id)
        // Deselect the item
        selectedItem = nil
    }
}

/// Renders a group of `FlowchartItems`.
/// 
/// **NOTE**: This view does not embed subviews in a stack.
struct FlowchartItemGroup: View {
    /// The flowchart that the items is part of
    var flowchart: Flowchart
    /// The array of items to display
    var items: [FlowchartItem]
    /// A binding to the selected item
    @Binding var selectedItem: FlowchartItem?
    /// Actions to perform for the item
    var itemAction: (_ itemID: UUID, _ actionType: FlowchartItemView.ActionType) -> ()
    /// Whether to draw a line at the end or not
    var drawFinalLine = false
    
    var body: some View {
        ForEach(items.indices, id: \.self) { index in
            let item = items[index]
            item.renderer.render(for: flowchart, selection: $selectedItem, itemAction: itemAction)
            
            if drawFinalLine || index != items.indices.upperBound - 1 {
                // Not last or draw final line set, draw a line
                FlowchartLine()
                    .frame(height: 40)
            }
//            PrintDebugView(text: "create item for: \(index)")
        }
    }
}

struct FlowchartLine: View {
    var body: some View {
        Rectangle()
            .foregroundColor(.secondary)
            .frame(width: 3)
    }
}

// MARK: - Flowchart Item View
/// Renders a `FlowchartItem`
struct FlowchartItemView: View {
    enum ActionType {
        case moveUp
        case moveDown
        case delete
    }
    
    var previewingItem: Bool
    var chart: Flowchart?
    var item: FlowchartItem
    var showContent: Bool
    
    typealias ItemAction = (_ itemID: UUID, _ actionType: ActionType) -> ()
    var itemAction: ItemAction
    
    @Binding var selection: FlowchartItem?
    
    init(chart: Flowchart, item: FlowchartItem, selection: Binding<FlowchartItem?>, itemAction: @escaping ItemAction) {
        self.chart = chart
        self.item = item
        self.showContent = true
        self._selection = selection
        self.itemAction = itemAction
        self.previewingItem = false
    }
    
    init(previewingItem item: FlowchartItem) {
        self.chart = nil
        self.item = item
        self.showContent = false
        self._selection = .constant(nil)
        self.itemAction = { _,_ in }
        self.previewingItem = true
    }
    
    var body: some View {
        HStack {
            // Used as padding
            if !previewingItem { itemActions.hidden() }
            
            itemContent
            
            if !previewingItem { itemActions }
        }
        .modify(if: !previewingItem) { modifyView in
            // Only add tap gesture if it's not in the object library
            modifyView
                .background(Color.white.opacity(0.001)) // Makes tap easier
                .onTapGesture {
                    // Set selection on tap
                    selection = item
                }
        }
        .id(item.id)
    }
    
    private var itemContent: some View {
        VStack(spacing: 12) {
            Text(item.name)
                .textCase(.uppercase)
                .foregroundColor(.secondary)
            
            if showContent {
                if let content = item.generateItemContent(for: chart!) {
                    Text(content)
                        .lineLimit(3)
                        .multilineTextAlignment(.center)
                }
            }
        }
        .frame(width: 150, height: showContent ? 76 : 60)
        .padding(.horizontal, 20)
        .padding(.vertical, 25)
        .background(
            item.shape.generateShapeView(isSelected: itemIsSelected)
        )
    }
    
    private var itemIsSelected: Bool {
        selection?.id == item.id
    }
    
    /// Display some actions when the item is selected
    private var itemActions: some View {
        VStack {
            Button {
                itemAction(item.id, .moveUp)
            } label: {
                Image(systemName: "arrow.up.circle.fill")
            }
            
            Button {
                itemAction(item.id, .moveDown)
            } label: {
                Image(systemName: "arrow.down.circle.fill")
            }
            
            Button {
                itemAction(item.id, .delete)
            } label: {
                Image(systemName: "trash.circle.fill")
                    .renderingMode(.original)
            }
        }
        .font(.title2)
        .buttonStyle(PlainButtonStyle())
        .isHidden(selection?.id != item.id) // Hide when not selected
        .isHidden(selection?.isGenerated ?? false) // Hide when item is generated
        .isHidden(selection is PlaceholderItem) // Hide when placeholder is selected
    }
}

// MARK: - Flowchart Shape View

extension FlowchartShape {
    @ViewBuilder func generateShapeView(isSelected: Bool = false) -> some View {
        let strokeColor = isSelected ? Color.blue : Color.primary
        Group {
            switch self {
            case .rectangle:
                Rectangle()
                    .stroke(strokeColor, lineWidth: 3.0)
            case .parallelogram:
                Parallelogram()
                    .stroke(strokeColor, lineWidth: 3.0)
            case .capsule:
                Capsule()
                    .stroke(strokeColor, lineWidth: 3.0)
            case .diamond:
                Diamond()
                    .stroke(strokeColor, lineWidth: 3.0)
            case .dottedRectangle:
                Rectangle()
                    .stroke(style: StrokeStyle(lineWidth: 3.0, dash: [4]))
                    .foregroundColor(strokeColor)
            }
        }
    }
}

// MARK: - Input Sheet
struct DataInputSheet: View {
    @Environment(\.presentationMode) private var presentationMode
    
    var variableName: String
    
    // TODO: iOS Support
    var completion: (String) -> ()
    
    @State private var inputText: String = ""
    
    var body: some View {
        macView
    }
    
    var macView: some View {
        VStack {
            TextField("Input data for \(variableName)", text: $inputText)
            
            Button("Done", action: done)
        }
        .frame(width: 320, height: 60)
        .padding()
    }
    
    private func done() {
        presentationMode.wrappedValue.dismiss()
        delay(seconds: 0.2) {
            completion(inputText)
        }
    }
}
