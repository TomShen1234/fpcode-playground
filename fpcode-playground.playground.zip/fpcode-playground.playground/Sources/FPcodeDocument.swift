//
//  FPcodeDocument.swift
//  Shared
//
//  Created by Tom Shen on 2021/1/30.
//

import SwiftUI
import UniformTypeIdentifiers

/// Document version supported by this version of the app
var FPcodeDocumentVersion = 1

extension UTType {
    static var fpcodeDocument: UTType {
        UTType(importedAs: "com.tomandjerry.fpcode-document")
    }
}

struct FPcodeDocument: FileDocument {
    enum DocumentError: LocalizedError {
        case incompatibleFileVersion
        
        var errorDescription: String? {
            switch self {
            case .incompatibleFileVersion: return "The version of this file is incompatible!"
            }
        }
    }
    
    var codeData: FPcodeData

    init() {
        self.codeData = FPcodeData()
    }

    static var readableContentTypes: [UTType] { [.fpcodeDocument] }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else {
            throw CocoaError(.fileReadCorruptFile)
        }
        
        let decoder = JSONDecoder()
        let decodedData = try decoder.decode(FPcodeData.self, from: data)
        
        if decodedData.documentVersion > FPcodeDocumentVersion {
            throw DocumentError.incompatibleFileVersion
        }
        
        self.codeData = decodedData
    }
    
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let encoder = JSONEncoder()
        let data = try encoder.encode(codeData)
        return .init(regularFileWithContents: data)
    }
}

struct FPcodeData: Codable {
    var documentVersion: Int
    var flowchart: Flowchart
    
    /// Initialize with default values
    init() {
        documentVersion = FPcodeDocumentVersion
        flowchart = Flowchart()
    }
}
