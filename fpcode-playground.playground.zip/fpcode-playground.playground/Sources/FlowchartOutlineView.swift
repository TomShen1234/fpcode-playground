//
//  FlowchartOutlineView.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/8.
//

import SwiftUI

// TODO: Optimize for iOS
/// Shows all Flowchart Items in an outline list
struct FlowchartOutlineView: View {
    @Binding var flowchart: Flowchart
    
    @Binding var selectedItem: FlowchartItem?
    
    @Binding var isOutlineSelection: Bool
    
    @State private var selectedTreeItem: UUID? = nil
    
    var treeItems: [FlowchartTreeItem] {
        flowchart.displayItems.map(\.treeItem)
    }
    
    var body: some View {
        List(treeItems, children: \.children, selection: $selectedTreeItem) { treeItem in
            let item = treeItem.item
            makeListContent(for: item)
        }
        .navigationTitle("All Items")
        .navigationBarTitleDisplayModeIfAvailable(.inline)
        .onChange(of: selectedTreeItem, perform: updateSelectedItem)
        .onChange(of: selectedItem?.id, perform: updateListSelection)
        .onAppear {
            updateListSelection(selectedItem?.id)
        }
    }
    
    func updateListSelection(_ itemID: UUID?) {
        selectedTreeItem = itemID
    }
    
    func updateSelectedItem(_ itemID: UUID?) {
        if let itemID = itemID {
            guard selectedItem?.id != itemID else { return }
            
            for item in treeItems {
                if let result = item.findItem(id: itemID) {
                    isOutlineSelection = true
                    selectedItem = result
                    return
                }
            }
        } else {
            // List deselected
            selectedItem = nil
        }
    }
    
    @ViewBuilder func makeListContent(for item: FlowchartItem) -> some View {
        let itemNameLabel = Text(item.inspectorPreview)
        
        #if os(macOS)
        itemNameLabel
        #elseif os(iOS)
        // Use custom toggle button on iOS
        Toggle(isOn: makeIsOnBinding(for: item)) {
            itemNameLabel
        }
        .toggleStyle(OutlineSelectionToggleStyle())
        #endif
    }
    
    // Custom row selection implementation on iOS
    #if os(iOS)
    func makeIsOnBinding(for item: FlowchartItem) -> Binding<Bool> {
        Binding {
            selectedTreeItem == item.id
        } set: { newValue in
            selectedTreeItem = item.id
        }
    }
    #endif
}

#if os(iOS)
struct OutlineSelectionToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        Button {
            configuration.isOn.toggle()
        } label: {
            configuration.label
        }
        .foregroundColor(configuration.isOn ? .red : .primary)
    }
}
#endif
