//
//  BottomSheetView.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/14.
//

import SwiftUI

// MARK: - Bottom Pullup Sheet
// https://swiftwithmajid.com/2019/12/11/building-bottom-sheet-in-swiftui/
/// A pull up sheet (similar to Maps) for use on iPhone
struct BottomSheetView<Content: View>: View {
    @Binding private var isOpen: Bool
    
    private var minHeight: CGFloat
    private var maxHeight: CGFloat
    private var content: Content
    
    @GestureState private var translation: CGFloat = 0
    
    init(isOpen: Binding<Bool>, minHeight: CGFloat, maxHeight: CGFloat, @ViewBuilder content: () -> Content) {
        self._isOpen = isOpen
        self.minHeight = minHeight
        self.maxHeight = maxHeight
        self.content = content()
    }
    
    private var offset: CGFloat {
        isOpen ? 0 : maxHeight - minHeight
    }
    
    private var indicator: some View {
        Capsule()
            .fill(Color.secondary)
            .frame(width: 50, height: 5)
    }
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                indicator.padding(8)
                content
            }
            .frame(width: geometry.size.width, height: maxHeight, alignment: .top)
            .background(Color(white: 0.7)) // TODO: Improve Color
            .cornerRadius(15)
            .frame(height: geometry.size.height, alignment: .bottom)
            .offset(y: max(offset + translation, 0))
            .animation(Animation.interactiveSpring().speed(0.6), value: isOpen)
            .animation(Animation.interactiveSpring().speed(0.6), value: translation)
            .gesture(
                DragGesture()
                    .updating($translation) { value, state, _ in
                        state = value.translation.height
                    }
                    .onEnded { value in
                        let snapDistance = self.maxHeight * 0.2
                        guard abs(value.translation.height) > snapDistance else { return }
                        self.isOpen = value.translation.height < 0
                    }
            )
        }
    }
}
