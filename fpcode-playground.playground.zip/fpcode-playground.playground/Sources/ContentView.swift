//
//  ContentView.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/8.
//

import SwiftUI
import Combine

let AddItemNotification = Notification.Name("fpcode.playground.additem")

struct FlowchartChallenge {
    var variables: [FlowchartVariable]
    var description: String
    var expectedOutput: String
    var hint: String
    var answer: Image
    
    func setup(document: inout FPcodeDocument) {
        document.codeData.flowchart.variables = variables
    }
}

/// Root view of the app, responsible for layout for the main screen as well as navigations
struct ContentView: View {
    @Binding var document: FPcodeDocument
    
    /// A flag to indicate whether we're running in the playground
    var isPlayground = false
    
    /// A flag to set whether the variable editor should be disabled
    var disableVariableEditor = false
    
    /// Set this variable to enable challenges
    var challenge: FlowchartChallenge? = nil
    
    /// Selected flowchart item is set here to allow all views in hierarchy to get access to it
    @State private var selectedFlowchartItem: FlowchartItem? = nil
    
    /// A flag indicating whether the selection came from the tree view
    @State private var isOutlineSelection = false
    
    /// Whether to show the object library on mobile (regular size class)
    @State private var showObjectLibrary = false
    
    /// Whether to show the inspector view
    @State private var showInspector = false
    
    /// The execution result to display in the alert
    @State private var executionResult = Result<String, Error>.success("")
    
    /// Whether to show the execution result alert
    @State private var showExecutionAlert = false
    
    enum SheetType {
        case variablesEditor
        case dataInput
    }
    /// Whether to show the sheet
    @State private var showSheet = false
    /// Type of sheet to show
    @State private var sheetType = SheetType.variablesEditor
    
    /// When the flowchart requests for input, create an instance of this struct
    /// and assign it to the `inputRequest` state to show a dialog.
    struct InputRequest: Identifiable {
        let id = UUID()
        var variableInfo: FlowchartRuntimeVariable.Info
        var completion: FlowchartRuntime.InputHandlerCompletion
    }
    /// See `InputRequest`
    @State private var inputRequest: InputRequest? = nil
    
    /// Listens for undo and redo and update the selected object state
    private var undoRedoNotification: AnyPublisher<Void, Never> {
        let undoNotification = NotificationCenter.default.publisher(for: .NSUndoManagerDidUndoChange)
        let redoNotification = NotificationCenter.default.publisher(for: .NSUndoManagerDidRedoChange)
        return undoNotification.merge(with: redoNotification)
            .map { _ in return () }
            .eraseToAnyPublisher()
    }
    
    #if os(iOS)
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    
    private var isRegularSizeClass: Bool {
        horizontalSizeClass == .regular
    }
    #endif
    
    var body: some View {
        Group {
            #if os(macOS)
            if isPlayground {
                playgroundView
            } else {
                macView
            }
            #elseif os(iOS)
            mobileView
            #endif
        }
        .onReceive(undoRedoNotification, perform: syncSelectedItem)
        .alert(isPresented: $showExecutionAlert, content: makeExecutionAlert)
        .sheet(isPresented: $showSheet) {
            switch sheetType {
            case .variablesEditor: variablesEditor
            case .dataInput: DataInputSheet(variableName: inputRequest!.variableInfo.name, completion: inputRequest!.completion)
            }
        }
    }
    
    #if os(macOS)
    private var macView: some View {
        NavigationView {
            outlineView
                .toolbar {
                    // Add the run button to the sidebar, like Xcode
                    runFlowchartButton
                }
            
            GeometryReader { geometry in
                let inspectorMaxWidth: CGFloat = 320
                // Split view for main view and inspector
                HSplitView {
                    mainView
                        .frame(minWidth: geometry.size.width - inspectorMaxWidth)
                        .background(Color.primary.colorInvert())
                    
                    if showInspector {
                        inspectorView
                            .frame(minWidth: 200, idealWidth: 250, maxWidth: inspectorMaxWidth)
                    }
                }
            }
            .frame(maxHeight: .infinity)
            .toolbar {
                ToolbarItemGroup(placement: .confirmationAction) {
                    toggleVariablesButton
                    toggleInspectorButton
                }
            }
        }
        .onAppear {
            // Show inspector by default on macOS
            showInspector = true
        }
    }
    /// Optimized for playground
    private var playgroundView: some View {
        GeometryReader { geometry in
            let inspectorMaxWidth: CGFloat = 320
            // Split view for main view and inspector
            HSplitView {
                mainView
                    .frame(minWidth: geometry.size.width - inspectorMaxWidth)
                    .background(Color.primary.colorInvert())
                    .overlay(playgroundLeadingButtons, alignment: .topLeading)
                    .overlay(playgroundTrailingButtons, alignment: .topTrailing)
                    .overlay(playgroundChallengeView, alignment: .bottomLeading)
                
                if showInspector {
                    inspectorView
                        .frame(minWidth: 200, idealWidth: 250, maxWidth: inspectorMaxWidth)
                }
            }
        }
    }
    private var playgroundLeadingButtons: some View {
        runFlowchartButton.buttonStyle(PlaygroundButtonStyle()).padding()
    }
    private var playgroundTrailingButtons: some View {
        HStack {
            AddItemToolbarItem(onAddItem: { item in
                NotificationCenter.default.post(name: AddItemNotification, object: item)
            })
            if !disableVariableEditor { toggleVariablesButton }
            toggleInspectorButton
        }
        .buttonStyle(PlaygroundButtonStyle())
        .padding()
    }
    @State private var showHint = false
    @State private var showAnswer = false
    @ViewBuilder private var playgroundChallengeView: some View {
        if let challenge = self.challenge {
            HStack {
                Button("Stuck?") {
                    showHint.toggle()
                }
                .buttonStyle(PlaygroundButtonStyle())
                .popover(isPresented: $showHint) {
                    VStack {
                        Text("Hint")
                            .bold()
                        
                        Text(challenge.hint)
                        
                        Button("Still stuck? See answer.") {
                            showAnswer = true
                        }
                        .popover(isPresented: $showAnswer) {
                            challenge.answer
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 250)
                                .isHidden(!showAnswer)
                        }
                    }
                    .frame(width: 200)
                    .padding()
                }
                .onChange(of: showHint) { _ in
                    showAnswer = false
                }
                
                Text(challenge.description)
                    .foregroundColor(.white)
                    .padding()
                    .background(Capsule().fill(Color.blue))
            }
            .padding(.bottom)
        }
    }
    #elseif os(iOS)
    private var mobileView: some View {
        HStack(spacing: 0) {
            if isRegularSizeClass && showObjectLibrary {
                outlineView.frame(width: 275)
                Divider()
            }
            
            mainView
                .toolbar(content: {
                    ToolbarItemGroup(placement: .navigationBarLeading) {
                        toggleSidebarButton
                    }
                    
                    ToolbarItemGroup(placement: .navigationBarTrailing) {
                        toggleVariablesButton
                        toggleInspectorButton
                    }
                })
                .overlay(makeCompactInspectorOverlay())
                .compactSheet(isPresented: $showObjectLibrary) {
                    // Inspector sheet for compact sizes
                    compactOutlineView
                }
            
            if isRegularSizeClass && showInspector {
                Divider()
                inspectorView.frame(width: 275)
            }
        }
    }
    #endif
    
    // MARK: - View Components
    
    private var mainView: some View {
        FlowchartMainView(flowchart: $document.codeData.flowchart, selectedItem: $selectedFlowchartItem, isOutlineSelection: $isOutlineSelection)
    }
    
    private var outlineView: some View {
        FlowchartOutlineView(flowchart: $document.codeData.flowchart, selectedItem: $selectedFlowchartItem, isOutlineSelection: $isOutlineSelection)
    }
    
    private var inspectorView: some View {
        FlowchartSettingsView(flowchart: document.codeData.flowchart, item: $selectedFlowchartItem) {
            // On item update
            guard let selectedItem = selectedFlowchartItem else { return }
            
            // Save changes
            document.codeData.flowchart.update(item: selectedItem)
        }
    }
    
    private var variablesEditor: some View {
        VariablesEditor(flowchartVariables: $document.codeData.flowchart.variables)
    }
    
    private var runFlowchartButton: some View {
        Button(action: executeFlowchart) {
            Label("Run", systemImage: "play.fill")
        }
        .help("Execute the flowchart")
    }
    
    private var toggleSidebarButton: some View {
        Button(action: toggleSidebar) {
            Label("Toggle Sidebar", systemImage: "sidebar.left")
        }
        .help("Show sidebar")
    }
    
    private var toggleInspectorButton: some View {
        Button(action: toggleInspector) {
            Label("Toggle Inspector", systemImage: "sidebar.right")
        }
        .help("Show the inspector view")
    }
    
    private var toggleVariablesButton: some View {
        Button {
            sheetType = .variablesEditor
            showSheet = true
        } label: {
            Label("Variables", systemImage: "slider.horizontal.below.rectangle")
        }
        .help("Edit variables")
    }
    
    private func toggleInspector() {
        withAnimation {
            showInspector.toggle()
        }
    }
    
    private func toggleSidebar() {
        withAnimation {
            showObjectLibrary.toggle()
        }
    }
    
    private func makeExecutionAlert() -> Alert {
        let alertTitle: String
        let alertMessage: String
        switch executionResult {
        case .success(let message):
            // Make challenge alert on success
            alertTitle = "Execution Finished"
            alertMessage = !message.isEmpty ? message : "No output was produced!"
            
            if let challenge = self.challenge { return makeChallengeResultAlert(challenge, output: alertMessage) }
        case .failure(let error):
            alertTitle = "Execution Failed"
            alertMessage = error.localizedDescription + " on selected item!"
        }
        return Alert(title: Text(alertTitle), message: Text(alertMessage))
    }
    
    /// Separate method for challenge alert to ensure minimal disruption with the original code
    private func makeChallengeResultAlert(_ challenge: FlowchartChallenge, output: String) -> Alert {
        let alertTitle: String
        let alertMessage: String
        if output == challenge.expectedOutput {
            alertTitle = "Congratulations!"
            alertMessage = "You did it!\nYour output is:\n\(output)"
        } else {
            alertTitle = "Not quite there..."
            alertMessage = "The expected output is:\n\(challenge.expectedOutput)\nYour output is:\n\(output)"
        }
        return Alert(title: Text(alertTitle), message: Text(alertMessage))
    }
    
    // MARK: - Compact size optimizations
    #if os(iOS)
    private var compactOutlineView: some View {
        // Wrap in navigation view
        NavigationView {
            outlineView
                // Add a close button
                .toolbar {
                    ToolbarItemGroup(placement: .navigationBarLeading) {
                        Button("Close") {
                            showObjectLibrary = false
                        }
                    }
                }
        }
    }
    
    /// Make settings overlay view for compact width
    @ViewBuilder private func makeCompactInspectorOverlay() -> some View {
        if horizontalSizeClass == .compact {
            GeometryReader { geometry in
                BottomSheetView(isOpen: $showInspector, minHeight: 75, maxHeight: geometry.size.height * 0.7) {
                    inspectorView
                }
            }
            .ignoresSafeArea(edges: .all)
        } else {
            EmptyView()
        }
    }
    #endif
    
    // MARK: - Actions
    
    /// There is updates to the data model, sync the selected item if possible
    private func syncSelectedItem() {
        if let item = selectedFlowchartItem {
            let targetID = item.id
            if let item = document.codeData.flowchart.find(target: targetID) {
                selectedFlowchartItem = item
            }
        }
    }
    
    /// Execute the flowchart and show the alert to display the result
    private func executeFlowchart() {
        document.codeData.flowchart.execute { result, failureItem in
            executionResult = result
            showExecutionAlert = true
            
            if case .failure = result {
                // TODO: Scroll to selected item
                selectedFlowchartItem = failureItem
            }
        } onInput: { info, result in
            // Create an input request to show the input dialog
            inputRequest = InputRequest(variableInfo: info, completion: result)
            sheetType = .dataInput
            showSheet = true
        }
    }
}

/// Apply to style all toolbar buttons for playground
struct PlaygroundButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .labelStyle(IconOnlyLabelStyle())
            .foregroundColor(configuration.isPressed ? Color(white: 0.8) : .white)
            .padding()
            .background(Circle().fill(Color.blue))
    }
}
