//
//  FlowchartSettingsView.swift
//  fpcode
//
//  Created by Tom Shen on 2021/2/14.
//

import SwiftUI

struct FlowchartSettingsView: View {
    /// The flowchart document
    var flowchart: Flowchart
    /// The item to edit
    @Binding var item: FlowchartItem?
    
    var onItemUpdate: () -> ()
    
    private var forceUnwrappedItem: Binding<FlowchartItem> {
        Binding {
            return item!
        } set: { newValue in
            item = newValue
        }
    }
    
    private var settingBinding: Binding<FlowchartItem> {
        forceUnwrappedItem.didChange(onItemUpdate)
    }
    
    var body: some View {
        VStack {
            // Header Text
            HStack {
                if let item = item {
                    Text(item.inspectorPreview)
                } else {
                    Text("No item selected!")
                }
                
                Spacer()
            }
            .font(.headline)
            .padding(.horizontal)
            
            Spacer()
            if let item = item {
                // TODO: Optimize for iOS
                VStack {
                    item.settings.generateView(for: flowchart, settings: settingBinding.storage)
                    Spacer()
                }
                .padding()
            } else {
                Text("Select item to inspect")
            }
            Spacer()
        }
    }
    
    /// Generated items (Start/end, Variable) cannot be selected
    private func isGeneratedItem() -> Bool {
        if let item = item {
            if item is StartEndItem || item is VariableItem {
                return true
            }
        }
        return false
    }
}
