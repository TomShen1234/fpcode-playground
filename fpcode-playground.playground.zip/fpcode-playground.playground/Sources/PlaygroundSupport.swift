import Foundation
import SwiftUI
import PlaygroundSupport

/// The configuration to start fpcode playground
public class FPcodeConfiguration {
    public enum Mode {
        case sandbox
        case tutorial
        case challenge(number: Int)
    }
    
    public var mode: Mode
    
    public init(mode: Mode = .sandbox) {
        self.mode = mode
    }
}

var document = FPcodeDocument()
var documentBinding = Binding<FPcodeDocument> {
    return document
} set: {
    document = $0
}

/// Launch the playground!
public func startFPcode(configuration: FPcodeConfiguration) {
    if case .sandbox = configuration.mode {
        runSandbox()
    } else if case .challenge(let number) = configuration.mode {
        runChallenge(number)
    } else if case .tutorial = configuration.mode {
        runTutorial()
    }
}

func runSandbox() {
    let contentView = ContentView(document: documentBinding, isPlayground: true)
        .frame(width: 800, height: 600)
    PlaygroundPage.current.setLiveView(contentView)
}

func runChallenge(_ number: Int) {
    guard [1,2].contains(number) else {
        print("Invalid challenge number!")
        return
    }
    
    func loadImage(named name: String) -> Image {
        let path = Bundle.main.path(forResource: name, ofType: "png")!
        let url = URL(fileURLWithPath: path)
        let image = NSImage(contentsOf: url)!
        return Image(nsImage: image)
    }

    let challenge: FlowchartChallenge
    if number == 1 {
        // Challenge #1
        challenge = FlowchartChallenge(variables: [.init(name: "arr", initialData: [25,10,32,47,6]),.init(name: "loopTmp", initialData: 0),.init(name: "sum", initialData: 0)],
                                       description: "Output the sum of all numbers within array 'arr'.",
                                       expectedOutput: "120",
                                       hint: "Create a for loop, where you can loop through the array's content. Within the loop add the number into the sum.",
                                       answer: loadImage(named: "challenge-1"))
    } else {
        // Assume Challenge #2
        challenge = FlowchartChallenge(variables: [.init(name: "arr", initialData: [25,10,32,47,6]),.init(name: "loopTmp", initialData: 0)],
                                       description: "Output the all numbers within array 'arr' that's greater than 20.",
                                       expectedOutput: "25\n32\n47",
                                       hint: "Create a for loop, where you can loop through the array's content. Within the loop, create an if condition check to see whether the number is greater than 20. Then output the number in the true branch.",
                                       answer: loadImage(named: "challenge-2"))
    }
    
    challenge.setup(document: &document)
    
    let contentView = ContentView(document: documentBinding, isPlayground: true, disableVariableEditor: true, challenge: challenge)
        .frame(width: 800, height: 600)
    PlaygroundPage.current.setLiveView(contentView)
}

func runTutorial() {
    PlaygroundPage.current.setLiveView(TutorialView())
}

struct TutorialView: View {
    var flowchartDescriptions = [
        0: "This block works exactly the same as the if block. But it executes a separate branch if the condition is false.",
        1: "This block sets a new value to a variable. If it is an array, it can also set a value within the array.",
        2: "This block performs a condition check. If the condition is true, the blocks within will be executed. It will continue to repeat the blocks until the condition becomes false.",
        3: "This block iterates a variable through a range or the content of an array. Every iteration a new value within the range or array will the set to the variable.",
        4: "This block will display an input dialog and assign the result to the specified variable.",
        5: "This block outputs the content of the specified variable.",
        6: "This block indicates the start and end of the flowchart.",
        7: "This block shows the list of variables inline within the flowchart. Set the variable using the variable editor.",
        8: "This block is a placeholder.",
        9: "This block performs an operation on an integer variable.",
        10: "This block performs a condition check. If the condition is true, it will execute the true branch.",
    ]
    
    var gridItems: [GridItem] = [
        GridItem(.fixed(250)),
        GridItem(.fixed(250)),
        GridItem(.fixed(250)),
    ]
    
    var allItems: [FlowchartItem] {
        flowchartLibraryItems
            + generatedItemTypes.map{ $0.createDefaultItem() }
            + [PlaceholderItem.createDefaultItem()]
    }
    
    var body: some View {
        VStack {
            Text("fpcode Tutorial")
                .font(.largeTitle)
                .bold()
            
            Text("This page shows a brief description on the function of each flowchart block in fpcode.")
            
            LazyVGrid(columns: gridItems) {
                ForEach(allItems.indices, id: \.self) { index in
                    let item = allItems[index]
                    makeTutorialCell(for: item)
                }
            }
            .padding()
        }
        .frame(width: 800, height: 950)
        .background(Color.primary.colorInvert())
    }
    
    func makeTutorialCell(for item: FlowchartItem) -> some View {
        VStack {
            FlowchartItemView(previewingItem: item)
            
            Text(flowchartDescriptions[item.type.rawValue]!)
                .frame(height: 80)
        }
    }
}
