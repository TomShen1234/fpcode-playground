//
//  FlowchartMainView.swift
//  Shared
//
//  Created by Tom Shen on 2021/1/30.
//

import SwiftUI
import Combine

/// Main view for fpcode with the flowchart editor
struct FlowchartMainView: View {
    @Binding var flowchart: Flowchart
    
    @Binding var selectedItem: FlowchartItem?
    @Binding var isOutlineSelection: Bool
    
    #if os(iOS)
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    #endif
    
    /// Used for playground
    private var addItemNotification: AnyPublisher<FlowchartItem, Never> {
        NotificationCenter.default.publisher(for: AddItemNotification)
            .map { $0.object as! FlowchartItem }
            .eraseToAnyPublisher()
    }

    var body: some View {
        VStack(spacing: 0) {
            #if os(iOS)
            // Use scroll object library on iOS
            FlowchartObjectList(onAddItem: addItem, displayMode: .stack)
                .frame(height: 150)
            Divider()
            #endif
            
            ScrollView {
                ScrollViewReader { scrollProxy in
                    FlowchartContents(flowchart: $flowchart, selectedItem: $selectedItem)
                        .padding(.vertical)
                        .padding(.bottom, bottomPadding())
                        .onChange(of: isOutlineSelection) { newValue in
                            if newValue {
                                // Selected from outline, scroll the view to make it visible
                                scrollProxy.scrollTo(selectedItem?.id, anchor: .center)
                                isOutlineSelection = false
                            }
                        }
                }
            }
            .onTapGesture {
                // Clicked outside, deselect the item
                selectedItem = nil
            }
        }
        .toolbar {
            #if os(macOS)
            // Toolbar button for item library on macOS
            AddItemToolbarItem(onAddItem: addItem)
            #else
            EmptyView()
            #endif
        }
        .onReceive(addItemNotification, perform: addItem)
    }
    
    private func addItem(_ item: FlowchartItem) {
        let itemContainer = FlowchartItemContainer(item: item)
        flowchart.add(item: itemContainer, after: selectedItem)
        // Select the new item
        selectedItem = item
    }
    
    /// Paddings to make room for the settings overlay if needed
    private func bottomPadding() -> CGFloat {
        #if os(iOS)
        if horizontalSizeClass == .compact {
            return 75
        } else {
            return 0
        }
        #elseif os(macOS)
        return 0
        #endif
    }
}

#if os(macOS)
// Use an add item button toolbar item on macOS
struct AddItemToolbarItem: View {
    var onAddItem: (FlowchartItem) -> ()
    
    @State private var showPopover = false
    
    var body: some View {
        Button {
            showPopover = true
        } label: {
            Label("Add Item", systemImage: "plus")
        }
        .help("Add new flowchart items")
        .popover(isPresented: $showPopover, arrowEdge: .top, content: {
            FlowchartObjectList(displayMode: .grid, onAddItem: onAddItem)
                .frame(width: 475)
        })
    }
}
#endif

fileprivate struct FlowchartObjectList: View {
    @Environment(\.presentationMode) private var presentationMode
    
    enum DisplayMode {
        case stack
        case grid
    }
    var displayMode: DisplayMode
    var onAddItem: (FlowchartItem) -> ()
    
    private var gridItems: [GridItem] {
        [
            GridItem(.fixed(225)),
            GridItem(.fixed(225)),
        ]
    }
    
    var body: some View {
        ScrollView(scrollAxis, showsIndicators: false) {
            switch displayMode {
            case .grid:
                LazyVGrid(columns: gridItems, content: makeContent)
                    .padding()
            case .stack:
                LazyHStack(content: makeContent)
            }
        }
    }
    
    private var scrollAxis: Axis.Set {
        switch displayMode {
        case .grid: return .vertical
        case .stack: return .horizontal
        }
    }
    
    private var paddingAxis: Edge.Set {
        switch displayMode {
        case .grid: return .all
        case .stack: return .horizontal
        }
    }
    
    private func makeContent() -> some View {
        ForEach(flowchartLibraryItems, id: \.id) { item in
            Button {
                var newItem = item
                newItem.id = UUID() // Brand new ID for new item
                onAddItem(newItem)
                if displayMode == .grid { presentationMode.wrappedValue.dismiss() } // Dismiss on macOS
            } label: {
                FlowchartItemView(previewingItem: item)
                    .padding(paddingAxis)
                    .background(Color.white.opacity(0.001))
            }
            .buttonStyle(PlainButtonStyle())
        }
    }
}
