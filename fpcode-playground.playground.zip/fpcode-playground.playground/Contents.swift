import Cocoa

/*
 Welcome to fpcode!
 This playground has 3 modes:
 1. Challenge mode: There are 2 challenges (see below) to complete using the flowchart blocks
 2. Sandbox mode: Do whatever you want! Make your own algorithms :)
 3. Tutorial: If you're unfamiliar with flowcharts, this mode shows a simple overview of all the blocks
 The default mode is the sandbox mode
*/

let fpcodeConfig = FPcodeConfiguration()

/*
 The 2 built-in challenges are:
 Challenge #1: An array is given with some numbers, output the sum of all the numbers.
 Challenge #2: An array is given with some numbers, output each number that's greater than 20
*/
// To enable challenges, uncomment the following line, and set the desired challenge number
//fpcodeConfig.mode = .challenge(number: 1)

// If you're unfamiliar with flowchart, uncomment the following line to see a tutorial
fpcodeConfig.mode = .tutorial

startFPcode(configuration: fpcodeConfig)

// End note:
// - The view is 800 points wide, increase the size of live view if parts are cut off
// - All implementation details are in the auxiliary module. If there are struct/method
//   error, simply ignore them, build and run. :)
